const config = {
    authRequired: false,
    auth0Logout: true,
    baseURL: 'http://localhost:7600',
    clientID: '7UcRAp1i1bGzzVbR0uN3IzPH4jycxlIA',
    issuerBaseURL: 'https://warehouseghana-erp.netlify.app',
    secret: 'a3OCH17u7Ncti0E6Qlypb7ZoAjA9theS0AhQmT8luIN2OkEBcR7PJLeCpRBsnsdV'
};

const Config = { config }

module.exports = Config;
