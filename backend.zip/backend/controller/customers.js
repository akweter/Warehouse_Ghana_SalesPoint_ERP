const { executeQuery } = require("../database/index");

/******************  GET REQUESTS  *********************/

// Return all customers and customers 
const allCustomersNSuplliers = async () => {
  const sql = `
    SELECT 
      i.C_name as userName, 
      i.C_tin as userTIN, 
      i.C_address as userAddress, 
      i.C_phone as userPhone, 
      i.C_region as userRegion, 
      i.C_status as userStatus, 
      i.C_email as userEmail,
      i.C_exempted as userExemption, 
      i.C_rating as userRating, 
      i.C_id as userID, 
      i.C_Added_date as userAddedDate,
      COUNT(ip.Product_Quantity) As ProBoughtQty
    FROM
      customers i
    LEFT JOIN
      invoice iv ON i.C_tin = iv.Inv_Customer_Tin
    LEFT JOIN
      invoice_products ip ON iv.Inv_Number = ip.InvoiceNum_ID
    GROUP BY
      i.C_name, 
      i.C_tin, 
      i.C_address, 
      i.C_phone, 
      i.C_region, 
      i.C_status, 
      i.C_email,
      i.C_exempted, 
      i.C_rating, 
      i.C_id, 
      i.C_Added_date
    ORDER BY 
      i.C_Added_date DESC
  `;
  try {
    const result = await executeQuery(sql);
    if (result) { return result }
  }
  catch (error) {
    return error;
  }
};

// Return all customers
const allCustomers = async () => {
  const sql = "SELECT * FROM customers WHERE C_status IN ('active')";
  try {
    const result = await executeQuery(sql);
    if (result) { return result }
  }
  catch (error) {
    return error;
  }
};

// Return only active customers
const status = async (prop) => {
  const sql = "SELECT * FROM customers WHERE AND C_status = ?";
  try {
    const result = await executeQuery(sql, prop);
    if (result) { return result }
  }
  catch (error) {
    return error;
  }
};

// Only one customer
const CustomerByTIn = async (id) => {
  const sql = "SELECT * FROM customers WHERE C_status = 'active' AND C_tin = ?";
  try {
    const result = await executeQuery(sql, id);
    if (result) { return result }
  }
  catch (error) {
    return error;
  }
};

// User Region
const Region = async (prop) => {
  const sql = "SELECT * FROM customers WHERE C_status = 'active' AND C_region = ?";
  try {
    const result = await executeQuery(sql, prop);
    if (result) { return result }
  }
  catch (error) {
    return error;
  }
};

// User Type
const Type = async () => {
  const sql = "SELECT * FROM customers WHERE C_status = 'active'";
  try {
    const result = await executeQuery(sql);
    if (result) { return result }
  }
  catch (error) {
    return error;
  }
};

// All Exempted
const Exempt = async (prop) => {
  const sql = "SELECT C_id, C_name, C_tin FROM customers WHERE C_status = 'active' AND C_region = 'local' AND C_exempted = ?";
  try {
    const result = await executeQuery(sql, prop);
    if (result) { return result }
  }
  catch (error) {
    return error;
  }
};

// One Exempted
const oneExempt = async (prop) => {
  const sql = "SELECT C_id, C_name, C_tin FROM customers WHERE C_status = 'active' AND C_region = 'local' AND C_id = ?";
  try {
    const result = await executeQuery(sql, prop);
    if (result) { return result }
  }
  catch (error) {
    return error;
  }
};

// One Rating
const allRating = async () => {
  const sql = "SELECT C_id, C_name, C_rating FROM customers WHERE C_status = 'active'";
  try {
    const result = await executeQuery(sql);
    if (result) { return result }
  }
  catch (error) {
    return error;
  }
};

// All rating
const oneRating = async (prop) => {
  const sql = "SELECT C_id, C_name, C_tin, C_region FROM customers WHERE C_status = 'active' AND C_rating = ?";
  try {
    return await executeQuery(sql, prop);
  }
  catch (error) {
    return error;
  }
};

// Return Search Customer
const queryProduct = async (user) => {
  const sql = `
    SELECT
      C_name as userName, 
      C_tin as userTIN, 
      C_address as userAddress, 
      C_phone as userPhone, 
      C_region as userRegion, 
      C_status as userStatus, 
      C_email as userEmail,
      C_exempted as userExemption, 
      C_rating as userRating, 
      C_id as userID, 
      C_Added_date as userAddedDate
    FROM 
      customers 
    WHERE 
      C_status  <> 'inactive' AND (C_name LIKE ?) 
    LIMIT 10`;
  try {
    const result = await executeQuery(sql, user);
    if (result) { return result }
  }
  catch (error) {
    return error;
  }
};

// Sales Dept customers
const Searches = async (prop) => {
  const sql = `
    SELECT
      C_name as userName, 
      C_tin as userTIN, 
      C_address as userAddress, 
      C_phone as userPhone, 
      C_region as userRegion, 
      C_status as userStatus, 
      C_email as userEmail,
      C_exempted as userExemption, 
      C_rating as userRating, 
      C_id as userID, 
      C_Added_date as userAddedDate
    FROM 
      customers 
    WHERE 
      C_status = 'active' AND (C_name LIKE ? OR C_tin LIKE ? OR C_phone LIKE ? OR C_email LIKE ?)`;
  try {
    const result = await executeQuery(sql, prop);
    if (result) { return result }
  }
  catch (error) {
    return error;
  }
};

// Add new custoner or supplier
const AddCustomerSupplier = async (prop) => {
  const sql = `
    INSERT INTO customers(
      C_name, C_tin, C_address, C_phone, C_region, C_status, C_email, C_exempted, C_rating, C_id, C_Added_date
    )
    VALUES (
      ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
    )`;
  try {
    const result = await executeQuery(sql, prop);
    if (result) { return result }
  }
  catch (error) {
    return error;
  }
}

// Update customer or supplier
const updateCustomerNSupplier = async (userData, userId) => {
  const sql = "UPDATE customers SET ? WHERE C_id = ?";
  try {
    const result = await executeQuery(sql, [userData, userId]);
    if (result) { return result }
  }
  catch (error) {
    return error;
  }
}

module.exports = {
  CustomerByTIn,
  allCustomers,
  status,
  Type,
  Exempt,
  allRating,
  oneRating,
  oneExempt,
  queryProduct,
  Searches,
  Region,
  allCustomersNSuplliers,
  AddCustomerSupplier,
  updateCustomerNSupplier,
};
