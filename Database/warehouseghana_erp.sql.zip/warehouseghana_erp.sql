SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


CREATE TABLE `all_action_logs` (
  `Acc_userID` varchar(20) NOT NULL,
  `Act_Log_ID` int(11) NOT NULL,
  `Act_Log_DateTime` varchar(50) NOT NULL,
  `Act_Log_Message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 230, '27/11/2024, 15:41:23', 'Login email sent to jamesakweter@gmail.com');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 231, '27/11/2024, 15:51:40', 'Login email sent to jamesakweter@gmail.com');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 232, '27/11/2024, 16:15:20', 'Login email sent to jamesakweter@gmail.com');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 233, '27/11/2024, 16:17:57', 'Login email sent to jamesakweter@gmail.com');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 234, '27/11/2024, 16:17:57', 'jamesakweter@gmail.com logged in the ERP. Details: {\"ip\":\"102.216.212.130\",\"city\":\"Kumasi\",\"region\":\"Ashanti\",\"country\":\"GH\",\"loc\":\"6.6885,-1.6244\",\"org\":\"AS329009 Spectrum Internet Service Ltd\",\"timezone\":\"Africa/Accra\"}');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 235, '29/11/2024, 11:45:40', 'Login email sent to jamesakweter@gmail.com');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 236, '29/11/2024, 11:45:40', 'jamesakweter@gmail.com logged in the ERP. Details: {\"ip\":\"102.216.212.130\",\"city\":\"Accra\",\"region\":\"Greater Accra\",\"country\":\"GH\",\"loc\":\"5.5560,-0.1969\",\"org\":\"AS329009 Spectrum Internet Service Ltd\",\"timezone\":\"Africa/Accra\"}');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 237, '29/11/2024, 19:56:49', 'Login email sent to jamesakweter@gmail.com');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 238, '29/11/2024, 19:56:49', 'jamesakweter@gmail.com logged in the ERP. Details: {\"ip\":\"154.161.132.172\",\"city\":\"Kumasi\",\"region\":\"Ashanti\",\"country\":\"GH\",\"loc\":\"6.6885,-1.6244\",\"org\":\"AS30986 Scancom Limited\",\"timezone\":\"Africa/Accra\"}');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 239, '03/12/2024, 11:00:33', 'Login email sent to jamesakweter@gmail.com');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 240, '03/12/2024, 11:00:33', 'jamesakweter@gmail.com logged in the ERP. Details: {\"ip\":\"102.216.212.130\",\"city\":\"Accra\",\"region\":\"Greater Accra\",\"country\":\"GH\",\"loc\":\"5.5560,-0.1969\",\"org\":\"AS329009 Spectrum Internet Service Ltd\",\"timezone\":\"Africa/Accra\"}');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 241, '04/12/2024, 11:58:07', 'Login email sent to jamesakweter@gmail.com');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 242, '04/12/2024, 11:58:07', 'jamesakweter@gmail.com logged in the ERP. Details: {\"ip\":\"102.216.213.10\",\"city\":\"Accra\",\"region\":\"Greater Accra\",\"country\":\"GH\",\"loc\":\"5.5560,-0.1969\",\"org\":\"AS329009 Spectrum Internet Service Ltd\",\"timezone\":\"Africa/Accra\"}');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 243, '05/12/2024, 22:23:43', 'Login email sent to jamesakweter@gmail.com');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 244, '05/12/2024, 22:23:43', 'jamesakweter@gmail.com logged in the ERP. Details: {\"ip\":\"102.176.94.80\",\"hostname\":\"102-176-94-80-dedicated.vodafone.com.gh\",\"city\":\"Obuase\",\"region\":\"Ashanti\",\"country\":\"GH\",\"loc\":\"6.2023,-1.6680\",\"org\":\"AS29614 Ghana Telecommunications Company Limited\",\"timezone\":\"Africa/Accra\"}');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 245, '09/12/2024, 10:53:02', 'Login email sent to jamesakweter@gmail.com');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 246, '09/12/2024, 10:53:02', 'jamesakweter@gmail.com logged in the ERP. Details: {\"ip\":\"102.216.213.10\",\"city\":\"Accra\",\"region\":\"Greater Accra\",\"country\":\"GH\",\"loc\":\"5.5560,-0.1969\",\"org\":\"AS329009 Spectrum Internet Service Ltd\",\"timezone\":\"Africa/Accra\"}');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 247, '12/12/2024, 08:59:21', 'Login email sent to jamesakweter@gmail.com');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 248, '12/12/2024, 08:59:21', 'jamesakweter@gmail.com logged in the ERP. Details: {\"ip\":\"102.216.213.10\",\"city\":\"Accra\",\"region\":\"Greater Accra\",\"country\":\"GH\",\"loc\":\"5.5560,-0.1969\",\"org\":\"AS329009 Spectrum Internet Service Ltd\",\"timezone\":\"Africa/Accra\"}');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 249, '12/12/2024, 13:50:08', 'jamesakweter@gmail.com logged in the ERP. Details: {\"ip\":\"102.216.213.10\",\"city\":\"Accra\",\"region\":\"Greater Accra\",\"country\":\"GH\",\"loc\":\"5.5560,-0.1969\",\"org\":\"AS329009 Spectrum Internet Service Ltd\",\"timezone\":\"Africa/Accra\"}');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 250, '12/12/2024, 13:50:08', 'Login email sent to jamesakweter@gmail.com');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 251, '13/12/2024, 19:22:29', 'Login email sent to jamesakweter@gmail.com');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 252, '13/12/2024, 19:22:29', 'jamesakweter@gmail.com logged in the ERP. Details: {\"ip\":\"154.161.171.0\",\"city\":\"Kumasi\",\"region\":\"Ashanti\",\"country\":\"GH\",\"loc\":\"6.6885,-1.6244\",\"org\":\"AS30986 Scancom Limited\",\"timezone\":\"Africa/Accra\"}');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 253, '14/12/2024, 15:38:26', 'Login email sent to jamesakweter@gmail.com');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 254, '14/12/2024, 15:38:26', 'jamesakweter@gmail.com logged in the ERP. Details: {\"ip\":\"154.161.171.40\",\"city\":\"Kumasi\",\"region\":\"Ashanti\",\"country\":\"GH\",\"loc\":\"6.6885,-1.6244\",\"org\":\"AS30986 Scancom Limited\",\"timezone\":\"Africa/Accra\"}');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 255, '15/12/2024, 06:36:17', 'Login email sent to jamesakweter@gmail.com');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 256, '15/12/2024, 06:36:17', 'jamesakweter@gmail.com logged in the ERP. Details: {\"ip\":\"154.160.27.19\",\"hostname\":\"dyn-at-mobile-154-160-27-19.mtn.com.gh\",\"city\":\"Winneba\",\"region\":\"Central\",\"country\":\"GH\",\"loc\":\"5.3511,-0.6231\",\"org\":\"AS30986 Scancom Limited\",\"timezone\":\"Africa/Accra\"}');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 257, '15/12/2024, 06:37:00', 'Login email sent to jamesakweter@gmail.com');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 258, '15/12/2024, 06:37:00', 'jamesakweter@gmail.com logged in the ERP. Details: {\"ip\":\"154.160.27.19\",\"hostname\":\"dyn-at-mobile-154-160-27-19.mtn.com.gh\",\"city\":\"Winneba\",\"region\":\"Central\",\"country\":\"GH\",\"loc\":\"5.3511,-0.6231\",\"org\":\"AS30986 Scancom Limited\",\"timezone\":\"Africa/Accra\"}');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG001', 259, '15/12/2024, 06:41:30', 'warehouseghana5@gmail.com logged in the ERP. Details: {\"ip\":\"154.160.27.19\",\"hostname\":\"dyn-at-mobile-154-160-27-19.mtn.com.gh\",\"city\":\"Winneba\",\"region\":\"Central\",\"country\":\"GH\",\"loc\":\"5.3511,-0.6231\",\"org\":\"AS30986 Scancom Limited\",\"timezone\":\"Africa/Accra\"}');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG001', 260, '15/12/2024, 06:41:30', 'Login email sent to warehouseghana5@gmail.com');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 261, '15/12/2024, 06:43:13', 'Login email sent to jamesakweter@gmail.com');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 262, '15/12/2024, 06:43:13', 'jamesakweter@gmail.com logged in the ERP. Details: {\"ip\":\"154.160.27.19\",\"hostname\":\"dyn-at-mobile-154-160-27-19.mtn.com.gh\",\"city\":\"Winneba\",\"region\":\"Central\",\"country\":\"GH\",\"loc\":\"5.3511,-0.6231\",\"org\":\"AS30986 Scancom Limited\",\"timezone\":\"Africa/Accra\"}');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 263, '15/12/2024, 06:46:00', 'Login email sent to jamesakweter@gmail.com');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 264, '15/12/2024, 06:46:00', 'jamesakweter@gmail.com logged in the ERP. Details: {\"ip\":\"154.160.27.19\",\"hostname\":\"dyn-at-mobile-154-160-27-19.mtn.com.gh\",\"city\":\"Winneba\",\"region\":\"Central\",\"country\":\"GH\",\"loc\":\"5.3511,-0.6231\",\"org\":\"AS30986 Scancom Limited\",\"timezone\":\"Africa/Accra\"}');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 265, '16/12/2024, 11:32:07', 'Login email sent to jamesakweter@gmail.com');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 266, '16/12/2024, 11:32:07', 'jamesakweter@gmail.com logged in the ERP. Details: {\"ip\":\"102.216.213.70\",\"city\":\"Accra\",\"region\":\"Greater Accra\",\"country\":\"GH\",\"loc\":\"5.5560,-0.1969\",\"org\":\"AS329009 Spectrum Internet Service Ltd\",\"timezone\":\"Africa/Accra\"}');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 267, '17/12/2024, 09:32:48', 'Login email sent to jamesakweter@gmail.com');
INSERT INTO `all_action_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 268, '17/12/2024, 09:32:48', 'jamesakweter@gmail.com logged in the ERP. Details: {\"ip\":\"102.216.213.70\",\"city\":\"Accra\",\"region\":\"Greater Accra\",\"country\":\"GH\",\"loc\":\"5.5560,-0.1969\",\"org\":\"AS329009 Spectrum Internet Service Ltd\",\"timezone\":\"Africa/Accra\"}');

CREATE TABLE `all_error_logs` (
  `Acc_userID` varchar(20) NOT NULL,
  `Act_Log_ID` int(11) NOT NULL,
  `Act_Log_DateTime` varchar(50) NOT NULL,
  `Act_Log_Message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `all_error_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 296, '17/12/2024, 17:10:01', 'Refund failed: Invoice was not found (OP24M106CSD)');

CREATE TABLE `all_message_logs` (
  `Acc_userID` varchar(20) NOT NULL,
  `Act_Log_ID` int(11) NOT NULL,
  `Act_Log_DateTime` varchar(50) NOT NULL,
  `Act_Log_Message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `all_message_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 13, '12/12/2024, 22:32:08', 'Quotation number: WG24M12121CSD submitted sucessfully');
INSERT INTO `all_message_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 14, '16/12/2024, 20:48:08', 'Invoice number: WG24M12121CSD submitted sucessfully');
INSERT INTO `all_message_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 15, '17/12/2024, 09:42:01', 'Quotation number: WG24M121CSD submitted sucessfully');
INSERT INTO `all_message_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 16, '17/12/2024, 09:44:23', 'Quotation number: WG24M122CSD submitted sucessfully');
INSERT INTO `all_message_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 17, '17/12/2024, 09:46:10', 'Quotation number: WG24M122CSD submitted sucessfully');
INSERT INTO `all_message_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 18, '17/12/2024, 09:47:08', 'Invoice number: WG24M124CSD submitted sucessfully');
INSERT INTO `all_message_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 19, '17/12/2024, 16:35:30', 'Quotation number: WG24M125CSD submitted sucessfully');
INSERT INTO `all_message_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 20, '17/12/2024, 16:40:54', 'Quotation number: WG24M126CSD submitted sucessfully');
INSERT INTO `all_message_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 21, '17/12/2024, 16:51:12', 'Quotation number: WG24M127CSD submitted sucessfully');
INSERT INTO `all_message_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 22, '17/12/2024, 16:51:21', 'Invoice number: WG24M127CSD submitted sucessfully');
INSERT INTO `all_message_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 23, '17/12/2024, 17:11:35', 'Invoice number: WG24M112314CSD submitted sucessfully');

CREATE TABLE `all_server_logs` (
  `Acc_userID` varchar(20) NOT NULL,
  `Act_Log_ID` int(11) NOT NULL,
  `Act_Log_DateTime` varchar(50) NOT NULL,
  `Act_Log_Message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `all_sucesss_logs` (
  `Acc_userID` varchar(20) NOT NULL,
  `Act_Log_ID` int(11) NOT NULL,
  `Act_Log_DateTime` varchar(50) NOT NULL,
  `Act_Log_Message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `all_sucesss_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 179, '12/12/2024, 22:04:33', 'Product: FDGFDG added succesfully');
INSERT INTO `all_sucesss_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 180, '12/12/2024, 22:04:33', 'Product: GHFGH added succesfully');
INSERT INTO `all_sucesss_logs` (`Acc_userID`, `Act_Log_ID`, `Act_Log_DateTime`, `Act_Log_Message`) VALUES
('WG004', 181, '12/12/2024, 22:10:27', 'Product: SUGAR MILK added succesfully');

CREATE TABLE `company` (
  `Com_name` varchar(70) DEFAULT NULL,
  `Com_tin` varchar(15) DEFAULT NULL,
  `Com_address` varchar(30) DEFAULT NULL,
  `Com_phone` varchar(15) DEFAULT NULL,
  `Com_email` varchar(35) DEFAULT NULL,
  `Com_id` char(36) NOT NULL,
  `Com_logo` blob DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `company` (`Com_name`, `Com_tin`, `Com_address`, `Com_phone`, `Com_email`, `Com_id`, `Com_logo`) VALUES
('WAREHOUSE GHANA', 'C0003453234', 'ACCRA', '0245152082', 'SALES@WAREHOUSEGHANA.COM', '3bc8f62e-7e10-11ee-a1e7-8cec4bf253e4', NULL);
INSERT INTO `company` (`Com_name`, `Com_tin`, `Com_address`, `Com_phone`, `Com_email`, `Com_id`, `Com_logo`) VALUES
('JN NOTEBOOKS', 'C0003275621', 'ACCRA - CENTRAL', '0540544768', 'PROCUREMENT@WAREHOUSEGHANA.COM', 'c833b703-e8d7-11ee-9816-8cec4bf253e4', '�PNG\r\n\Z\n\0\0\0\rIHDR\0\0\0\0\0\0�\0\0\0����\0\0 PLTE����$3\"8#=�#1#<\"7!9\0\0%$=�#3#?\0\0(\0\0#\0\0\'\0\0!\0\0+\0\0�\0�	!\0\0\0\0-\Z9\0\0\0\01����,\0\0\0-4\009������3�\0�����������엚����%->\02�����������ڢ��匒�^f���IN[�6C���rv~^bn��؉���(7�?L���~��LW멭眠����px[`k���\0\0\r�\0	mn|@EV**?}v��_g�u{薝�-<17F煍?EPSWh9>Q,3I+\";e_jA<LKDU3ƿĕ��\Z6\0\04WO_-�r!\0\0<IDATx��]	C�J�B��ei�@$�J�f����.�(ֶW�Z����/�93�̠B�����m�1$3\'g�>\'���m<��\0������t�)�a�C�*�������4�_�F���G1=<_����icz��G�����1-|��Q���}���(\0�\'jl���G���=��`؟≪�W�h���if\nX�gճ����c���=����lTD�Ӵ��x]!@��n�#z\\|e\0 �������p����2�L��S\n�\r\'�Lݧ@�	YC�\r�@��O&0��\r;?fų��c�{��\0���(���L{d��wL��>q}P|\"��~0e=�}Ya�@�?\rk�����y��G~�y|.���ח0\Zh������\r��g\Z����������Qt�^�R��⥏Sރ��:&�6{+�Eo�=��\"3�����\0��x�3g��)�����`=J�`?s�*��X��+q��p�����\"Bx$����,3�I(��$J[��%��Y6�����Q��Ԙ�ȵ\"\"e�1��������\r��K(�����o��:`�1����Kz0��k��k��Nd� �Yk�3��0Z-+����\r��=3��3*?�@ �z�)�bT������)?�g��e��$|(eP��̦#�9��Tb�*|�m�xq���.�1�^H(��*��&���,\Z9�2@��k�X@��Rو���vbv�bC+<��ϝ��8 �B�\'*�O{���O��Չ÷��l�b�58���J�K3��K:\0h�4Rhp�2�ȈA<k��kAǽ�D���嗶0��f*6���#���]B\"Y�%>c,��#����r�2��\n��\nϙDg)Y���`Q��Ҋ��kh=��ҏ���of&Y�L0�x���Xha�������i����G}���e)�W�J@b\rmfY� >+���y֣��[����k\\�`\r�?�&���|��KA��z���r��dr(�\Zz+8ͳQ=�VP�(�ک��1t�?eFb\r1�X׳��=�{\0x�\\�q��`d\0�\n���ZCB�8�����ۦ��^`\ZCA�@\n��4ZCA�\0����b۶m1�G6F	Fp���Y�J1�O�T��K&>l\0^�|���;`�������ψ>�y��=�ʮb1���\0��Fp�A��2ϸ���m!B<]�x%:�A1[�q��W���G� \0����	�\0��۴SlU(j�TҳoM�d����(���B���:���O�!j*�\0S��>%&+�ZN�_@�O�\'z��G`9��-_��)�I��m�<F��4k���2��A�[{����窱r!����������\'���/�Xe]�U��J����MoGի�c�85�w*�@�Ӻ\0����%be,\Z���$J�Ô|\"����=�oD���Fn�%�-�B���C�2���\r�0���?\r�T �D/=�n��A�#�H�Z�̛K6��B4��Ⴕ$τ�����)�[���y�n���[��^0<���;��,��������T!x�-&X`6��~�39Y��^:�\0\Z���٪��Tc����f 	���q��f�6�磊h�ZmD���Q45�.b��y0�^�\0��L(�:\Z��|c��Żj:�VS�L0�can��\\&����V��J*����(��g#��m��,���*����W$|E\r~���蠣�}1��w�/�G\0��s�N��6�`��?�[\\S�+��{���\0<8��B�T!�$��X��\'M�H�{�N��]���<�(,=�[�^�0��bD\"�X\"���<*=�[���,�Ge�7@LQ�km\0v������&0���-n�F�e�\n�~	�~�bqxx�F�Kp8��Ӵ����_�A|�#���h4R]�R\0�B��>�I(��<j8�V���f՜�:��l1�����u��\\�ǂ}������#��RG�b�APb:nq(��^CCs<6�4�u��hU|)��U3�>���輷^��s̞|����\'�ⱣD�b���Il��W�/�y��V�\'�|Q0$O�ʬ���O\r�;�Uυ�3٧�q��rs���n;3UD=]��M����3UG?^BH\"�[�-�Z�����4�Q�;	F�_�=�G��p�-�$<q��<0�`����P��%aa����	@�\'yͽ>�=\ZB��╨`<	�X���T�dIH>	�j�|�.��$���»&$(12��\"#:�B6�谲Zp����������S�\0q�y��Cg��I]�Im��&\\SF5ZJu}M�^�k�-�\n�}!2r�n�Wmu:�^���?Df��4O���C���;`���&$2�8��ް�����iY�[�ʄ��x��\Z��x1~{\'=��\'\0���\rH��-n��,˒aH��b(��Rx.�Wv��B��\'���\r�[,4۹7��>��b�fn�4}���g�N�G��([�K,p ������5��$�zڜ���oo�eL�&�%DF�Vp,pO�b0Ǟ�\0�p��������	ˬZRx-�V�I/�{��e�LBd�\0�\r.?ߙ�&�{xp�b�����)�n������%�9���*>��~uB��?]���O0l��\"���G�$ [���B�����l�#-�������Lم��v����[�4 K_�o���\Z�?Y.`� X��0�&����X�/���՝�o��M;����*�6ϳ�ߒ~n�f���Xc�)�\r55�b)Ƴ�V,r؋6�mFX�w�R72j��-�Yl��K�,2\n��_�`��K��:�[��Y_F`�;��U�3�To�Ņ�\Z�\0���?`��Ǌ�����:s�9[�%0\0٦�1��-���\\�3чي.⟫ظ��Q�u�ކw]R���8����[˭v���p���i0�ps�XQ��u\0Q�)\nww��\Z(�i�#6 ��[|���(_��\'-��H\nywzT��~0P��r($�1�N�e�x�cX>���.{�;)��e�!�K����.8X=��)���\"rpW��;��ν��{1�\r`���3��;\Z~f@��}�܍\0ɉ,���s�lc�~��k=S��% K��]�l��r���\n�j5M�N��qI\"�������|\"=z{u��^��ӯ��b@�b_P1�����%�XX`ƛx�*��]�j�\n ^Ћ,Sj� �@D\\t-m��n��vR��\'\0�P�q����ǭX��D����ЊL��\\_��T����	,���$H� �α&��w�A%�b>pux�� ��E�|�����E���l�Fp�rd�Ț��{ö�	P���v��.ނ<+ƇK�ٵz�NU����bl���hl���i$�@b�8G\ZzP$�p0��e��|�L&�T�\\���e�c�2�~E��nSG��2��n�Gn̇�ٯ	���FA)������t�i��TM�\0��������N}�[k�z�F��nU�ɏ�U��Jɾ�w����v��9CP#M}߰�F1����	F��#�@fZUM�����ll���`��v\'���-^/�\\)�y�]`��Q0آuh�`Fzx��3(�9\\88�V��H��\'\0�|�\\d[)�ی���O�=\Z\n��W�E�0�V��?a�<D���矸[��;-�q-��p��+��e�ye��ƭ�v#x&ϕ*%7���^��5Klk��8wY��g��䉑�`���4\'\0iC|p�խ9,��Ļ� z�\\�\'f1�Y��Ǖ�쬅}�.���\n�6D^� 41���HC��$�-0@ط�d��mE��99>�s�%�*�0~��f��->r�\n$�@�\0���4A�S-(������%�4���o,�yd��6�В��X�lC�h/�ylo��2HX�;��C�eC��{9��J��m\0|f��Zg��,�\0�\r4�f�ɀ�zؗ�[��*�\\�42R���Q�L�R�2���Q`^�f��e�\rag-i5#���]�<�+\\b�p\"�����Xzh�yB�f��tKB2��o���px�ĳa�;Gy\Zx�c���V\n)|��ިyՉ�5���\07�`*���ҸB�ɉ��\r;ސ�xqb��DF�x�J6��;������0��\n����{�6T�gC��� ��mB64���1�5��b���6�F�@��MydD�����iyd\0!�Z��A��n�sx��	�F+�3�;�a@��!�����pÞD�\'�w���xr;�l\0\r-�Gk�S�t����>a���¥8�2g�l�?�	6\0Y�>F���a6\0�-x$��ؔ\'B�Ӏ!�i�B�����\\�U�`��%XN�(O� �d�U�h�IpL�R61�q(��2-���]����ӯW����&V|?�nyyeq�Y-X��9 \0�-x4��N$Hple��œrG]Iu4�?�u�BSx�R<(k�XY�^�.\n^��I������\ZY�F�O#��ts��9�v`Y`�(_��\0�����|u���ep5k�L\0N����aY��������)eǩ�J%5�VS��ۘ{5�>��d2m!��z�.�?V�m�+����-�d*����0R�����M�����폯b�1�T�(������e(>xp��\0��s�H���#￹\\���m�ڼ�Z����qXV\\3ū���t\"o,�\n�ckFzif�^og�cg<�i0h�Q`p&����]��	Z<�*�a���0{� ��n\n5j�Gآ�n�\\	����,�*y�a6�7�>�,\Z���\\��	e�f*�`P�N��]���/�a�s��V��:*Kk��@���\0c���2��B<_Z�(n/�r\rX�\0\ZI/�]�?ѳGA$�F6P7��`:�<H<�p��iF���!he!?\\��	_	�躺�Ɠ#�xA�n�����<//qBm�ֳz��zq����cdI��bXX��㥈�����������+��haʚ�˯FF����D��K��ˎ��������6a\06+<�Z���\n��S�oĸ�D/���#�f����m��6~�~Pp�{~ ̐&V�<6V�W�^���\Z.��;��bI䤺�����VVV����s����� �5#�k�s��Eϔy�\\�&��m6a.d������W�>}����������\Z�B/>}��F\n����l��q�P�f\r,5�r�@��yS��_Q��\'���&���/m���������>�u�R/��¢Wށ%�7��H�㎢^�[	v����I1�C��0�����3�>ad�7���>��ۓ�K5���0��}���/\0��e���;W2_�l����86#A������\r�!���\0Ad�v�B�q�7�P��L�X͈�(�F�9��Թ`��\\A�I3@@^����K}\r��>�{A�u﫼����:܀�j8�$�h<�%�� �V��;����{�֩}@5>��;_�sNߨ�!o�!�}���o�اx��Y���tD��x�� �VR�FF��q7O��:�\'�x�����?L���4���(�Aώ����Dr:\'<����\Z6W�[�!5q��U��������	W�w�Yvg�qr��[E�&M��9ޗ$��f��n��l7�k�n휈��\'��y�^��?�w[���A�yq��PM�U�U�o��9�{q\"i{f,��F�+n�v��\"�͂�����˅��?��̪X%+���V�/u2G�5�I���H����W�~�u�k�}~j�`DY�	��[��&)���>֟�H\Z2ܰFU�i<��\\.e9!�����23�j�S�ʟF.�`���i��<�2�3k����I�)8_�oV3�+�,ma]�az�S�d9kv������mU�I\"�=�0��E��f.V|x}�&9[��@.�;��\n��A;.�F�}��0U��̊,i�O�;u�co��5���}�a����\'*6]C6��fsxVwl�]�I��%\r��y{�Z��}��hs}��i������Uv�f�3GrO(�0g�+�\\$���qI*�=��a�NҐ5�\rN=tdMm�M�R+R�c�R�����bF/�+I2)P�ebZ���Z�&;��X6��A�P�t��9#�Y@��`\Z�đ��rk������$��(\Zyz\'eɨcȹV��,�U+�n#�k�Ӛ��N\ZA���ŉ۶$Y3�Q�4�{V� �Z\Z���6M�3������SGƧ��<�a�1���i� �K�\Z���4�������uyn�HY2ȷ��b��E��Y\rH�e�a�#;�:&z\"5K6,\\\"��D��\r&gL;�ct��հ�P��,�<c�+\\�t�%*\r#����>-�`��r�\0��k`!�sJ����9K�3p�8I�)�fH��\"�eʿ@\\���h\'���9L��}[�?��0���R�N�L�V�{�)�H\0�w^��T�N���nZ��ʆ��J�\0����$��E,�l��irr��ʗ�3�\'I����.IΝ�#��䜵;y��tϔ\rc��5G3�2\'�O�t]�@6���9��$cEJ^9iQ*j�Өn��7y��d\0ДS�ש\"��Uzp5y�)p#�x�$C��:�����:����\n��8���٦�s�	�:��j@\0�H͕\r)�`8s)#I��l�+o:�l ـ����V�5��i��\'��.䚄��Sr�,V�� (�v�Ӳ}F�P0h͢���=\\ n�|�A^c��Vp�\0-װd��� ��a��)0LC����ƴ����K�p\\,�~�\'\0<��]\'�	\0�::[�Ӏ\0@ų2��D�A�\0�p��\0&!@d#�����zH��C�ΥT�T���P��6Gy/���@��|�h$]���l�~� ��8s��,�$�\0[���A�b{;C��:�*�9g�h��lg(�T��\\�UwᱺIB�òf�F\"Gf�\'\0茮��ҥbU����7�\0�&�ET���1�\Z�[X�1PÜP]�\r͌?0�g�&Ǵ:Hj �\\��X�	\0��?��N)P�x;I����co�N你eOl9\0i�k�泪��`�6!�~�~A�H�y(�\'_����\\��L�.Y�\ZL��4N����nX��[!�<R��,X�@2)�l���jE�@(��Ϩ�k%s{�dȅ~�,ME҂!�/�k̵*\n� F�C�1���`hI�k�b�G�0hZ1U<r�$�&�k~����G�=b���N��\\��R���g�Hr-�m�A8\0I���wKz�����`�^�>rp�&�����	�cT����6��Qd��-����h_�D:ο{{{\n0�Q�]d[j@\0o�q~���v� ���\0͇v�p���g�����[����f�\Z��!������*��)��a]��8��p��{g����3�&��֫�9R\n��~��Simzu���a���y\nV���ڠ���P1���ȳN�k���\0�|T�@�N��ư˲�/m�7Fo��H��S\'FV�0ܻzR���q��-��lbg8�A�-_�X�@�a�Q��9�}5���¶�D�r{\rSL)�u�!V{{Arͣ3SҔ������7֒�$�TM4�a�N��W%i���4Q~9�v�_��x�ꡃ���&��S��/�K@�TpE:Gh�;����;sֿ���� �[��7�N~�Pi�|�șnݭ��\n`m8s�᳤�L�w2��[��g�VN�GNrVݵT�n:g��8n^�Զ��Ywu+uJ�^K�0k�~�\"�\'�L�RI+/��틔Uq\\+���T��J�[�L��I�\\�Uw�)�\r\\I.DR&xO_�r�S���W˭,�U����Vς�7��%=�\r�M<d7�|nE�=���@�~���$z��W���5V�Dd�N��c���`�\n%�s8�m2���4��A�J�s~��p������M_ny�U:@;��K~�5qī=�M2p��У�j�Z�$���/��IߣC\0\0\0\0IEND�B`�');
INSERT INTO `company` (`Com_name`, `Com_tin`, `Com_address`, `Com_phone`, `Com_email`, `Com_id`, `Com_logo`) VALUES
('SAMPLE COMPANY LIMITED', 'C0003453234', 'ACCRA', '0245XXXXXX', 'EMAIL@COMPANY.COM', 'HA98S34', NULL);

CREATE TABLE `customers` (
  `C_name` varchar(70) DEFAULT NULL,
  `C_tin` varchar(15) DEFAULT NULL,
  `C_address` varchar(30) DEFAULT NULL,
  `C_phone` varchar(15) DEFAULT NULL,
  `C_region` enum('local','foreign') DEFAULT 'local',
  `C_status` enum('active','inactive') DEFAULT 'active',
  `C_email` varchar(35) DEFAULT NULL,
  `C_exempted` enum('Taxable','Exempted') DEFAULT 'Taxable',
  `C_rating` int(11) DEFAULT NULL,
  `C_id` varchar(10) NOT NULL,
  `C_Added_date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('TROPICAL ARCTIC LOGISTICS GHANA LIMITED', 'C0003314324', 'KUMASI', '0540544869', 'local', 'active', 'UNCLE@GMAIL.COM', 'Taxable', 4, '0A47B9E', '2024-12-12');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('DOPHIL ROOFING SYSTEMS LTD', 'C0000000000', '', '0270039044', '', 'active', '', 'Taxable', 2, '0B16EA8', '2024-12-17');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('PAA BRIGHT', 'P0030588901', 'TEST NAME', '0540540283', 'local', 'active', 'BRIGHT@GMAIL.COM', 'Taxable', 2, '12B1F3B', '2024-12-12');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('WAREHOUSE GH', 'GHA-29273889-2', 'KANTAMANTO', '0240162082', 'local', 'active', 'SALES@WAREHOUSEHANA.COM', 'Taxable', 3, '14CD7F3', '2024-12-09');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('MICHAEL', 'C0000000000', '', '0248915772', '', 'active', '', 'Taxable', 2, '32D652E', '2024-09-24');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('DORTOH FORSTER KWABENA', 'C0000000000', '', '0245872375', '', 'active', '', 'Taxable', 2, '333B295', '2024-09-27');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('ROCK CITY HOTEL', 'C0000000000', '', '0593826302', '', 'active', '', 'Taxable', 2, '444C693', '2024-08-30');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('TESTING GRA BACKEND', 'C0000000000', '', '0540547632', '', 'active', '', 'Taxable', 2, '5683766', '2024-12-17');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('CLIFTON HOMES', 'C0000000000', '', '0557092798', '', 'active', '', 'Taxable', 2, '61C950E', '2024-12-17');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('DAVID ADJAYE', 'C0000000000', '', '0261633626', '', 'active', '', 'Taxable', 2, '6D56E31', '2024-12-17');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('DONAJOS COMPANY LIMITED', 'C0000000000', '', '0591444360', '', 'active', '', 'Taxable', 2, '6FA9619', '2024-09-24');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('OFORI BAAH COMPANY LIMITE', 'C000345234', 'ACCRA', '0540544760', 'local', 'active', 'OFORI@GMAIL.COM', 'Taxable', 3, '721EEB9', '2024-11-24');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('CLEANEATS LIMITED', 'C0000000000', '', '0249905004', '', 'active', '', 'Taxable', 2, '751CDF3', '2024-08-02');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('HALFAST LIMITED', 'C0000000000', '', '0556664371', '', 'active', '', 'Taxable', 2, '79B2F77', '2024-08-01');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('Q3 COMPANY LIMITED', 'C0000000000', '', '0244016017', '', 'active', '', 'Taxable', 2, '7EF6983', '2024-08-20');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('AMPONSAH BAAH', 'C4000000000', 'KOFORIDUA', '05405447603', 'local', 'active', 'AMPOSAH@GMAIL.COM', 'Taxable', 0, '863E912', '2024-11-24');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('AKWETER JAMES', 'C0000000000', '', '0540548323', '', 'active', '', 'Taxable', 2, '881931F', '2024-11-23');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('GEORGE ODURO', 'C0000000000', '', '0266154410', '', 'active', '', 'Taxable', 2, '97322A1', '2024-09-24');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('MIKADU CONSTRUCTION LTD', 'C0000000000', '', '0273055354', '', 'active', '', 'Taxable', 2, '991C8B6', '2024-10-09');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('ROLIER GHANA LIMITED', 'C0000000000', '', '0244337615', '', 'active', '', 'Taxable', 2, '9984F74', '2024-08-13');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('OPPONG KORANTENG', 'C0000000000', '', '0592425636', '', 'active', '', 'Taxable', 2, '9A3021A', '2024-08-01');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('OSEI BARIMA', 'C0000000000', '', '0540544762', '', 'active', '', 'Taxable', 2, '9C1C0A4', '2024-11-03');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('AKWETEY', 'C0000000000', '', '0246399267', '', 'active', '', 'Taxable', 2, '9D91D3B', '2024-09-25');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('PROF. SAMUEL OWUSU ABABIO', 'C0000000000', '', '414559-3567', '', 'active', '', 'Taxable', 2, 'AC22926', '2024-08-15');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('HEPZIBAH', 'C0000000000', '', '0547494450', '', 'active', '', 'Taxable', 2, 'B22B1DD', '2024-08-19');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('UNCLE JUMIA', 'C0000000000', '', '0540544321', '', 'active', '', 'Taxable', 2, 'B2CA8C7', '2024-10-14');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('WAREHOUSE GHANA', 'CXXXXXXXXXX', 'ACCRA CENTRAL', '233245162082', 'local', 'active', 'SALES@WAREHOUSEGHANA.COM', 'Taxable', 4, 'B3B39EE', '2024-12-12');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('ADJAYE ASSOCIATES', 'C0000000000', '', '0207739253', '', 'active', '', 'Taxable', 2, 'B57BEDD', '2024-10-30');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('LORD SIR', 'C0000000000', '', '0247616024', '', 'active', '', 'Taxable', 2, 'C047DA1', '2024-08-31');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('AKWETER JOHN', 'P0030588901', 'ACCRA - GHANA', '325345234645', 'local', 'active', 'UNCLE@GMAIL.COM', 'Taxable', 5, 'CE6923E', '2024-12-12');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('YIBA FRESH', 'C0000000000', '', '0555960406', '', 'active', '', 'Taxable', 2, 'D487AC1', '2024-10-21');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('ABEIKUMAH CONSTRUCTION', 'C0000000000', '', '0200316265', '', 'active', '', 'Taxable', 2, 'DB2375A', '2024-08-19');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('ANDOP COMPANY LIMITED', 'C000713911X', 'OFOASE KEKEBI', '05405448298', 'local', 'active', 'ANDOP@GMAIL.COM', 'Taxable', 4, 'E05933A', '2024-12-12');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('JN-AKWETER ENTERPRISE', 'GHA-428347939-2', 'ABLEKUMA - ACCRA', '233540544760', 'foreign', 'inactive', 'JN-AKWETER@GMAIL.COM', 'Exempted', 3, 'E531CFE', '2024-12-12');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('NEW CRYSTAL HOSPITAL', 'C0000000000', '', '', '', 'active', '', 'Taxable', 2, 'F5D3A97', '2024-09-26');
INSERT INTO `customers` (`C_name`, `C_tin`, `C_address`, `C_phone`, `C_region`, `C_status`, `C_email`, `C_exempted`, `C_rating`, `C_id`, `C_Added_date`) VALUES
('CSS PRECISE SYSTEMS LTD ', 'C0000000000', '', '0544886000', '', 'active', '', 'Taxable', 2, 'F9D9BB1', '2024-08-30');

CREATE TABLE `inventory` (
  `Itm_autoincrement` int(11) NOT NULL,
  `Itm_cat` varchar(25) DEFAULT '""',
  `Itm_name` varchar(200) NOT NULL,
  `Itm_status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `Itm_img` blob DEFAULT NULL,
  `Itm_qty` int(11) NOT NULL,
  `Itm_price` int(11) NOT NULL,
  `Itm_sup_id` varchar(50) NOT NULL DEFAULT '""',
  `Itm_usr_id` varchar(50) NOT NULL,
  `Itm_taxable` enum('CST','EXM','','TRSM') NOT NULL,
  `itm_date` date NOT NULL,
  `Itm_id` char(36) NOT NULL,
  `Itm_UOM` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(317, 'RS', '0.3MM HIGH QUALITY ALUZINC ROOFING SHEET', 'Active', '', 1000, 1900, '9E7AAB4', 'WG001', '', '2024-05-07', '00A9212', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(356, 'BLOCK', 'QUARRY DUST CONCRETE BLOCK', 'Active', '', 10, 12, '9E7AAB4', 'WG001', '', '2024-05-07', '0399D1F', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(382, 'RS', 'ROOFING SILICON', 'Active', '', 7500, 126, '9E7AAB4', 'WG004', '', '2024-09-03', '078F1E3', 'PC');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(376, 'EPS', 'X-LARGE STYROFOAM ICE COOLER STORAGE', 'Active', '', 100, 150, 'VT0021', 'WG001', '', '2024-07-02', '081214B', 'PC');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(327, 'RS', 'IBR-PREMIUM ALUZINC ROOFING SHEET 0.4MM ROUGH - GREEN ', 'Active', '', 100, 2450, '9E7AAB4', 'WG001', '', '2024-05-07', '0A6B5FA', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(349, 'RS', 'PPGI ROOFING SHEET - BLUE', 'Active', '', 1000, 1250, '9E7AAB4', 'WG001', '', '2024-05-07', '0B35360', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(347, 'RS', 'PPGI ROOFING SHEET - RED', 'Active', '', 1000, 1250, '9E7AAB4', 'WG001', '', '2024-05-07', '0E603B6', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(362, 'RS', 'TRANSPARENT ROOFING SHEET - GREEN', 'Active', '', 1000, 150, '9E7AAB4', 'WG001', '', '2024-05-07', '11808F2', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(384, 'RS', 'ANTI CORROSIVE ALUMINIUM SIDE-TRIM', 'Active', '', 200, 20000, '9E7AAB4', 'WG004', '', '2024-09-03', '1561627', 'PC');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(340, 'INSULATION', 'MINERAL WOOL CAVITY BATT WALL INSULATION - 50MM', 'Active', '', 1000, 1298, 'A2C35DF', 'WG001', '', '2024-05-07', '1797BBD', 'ROLL');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(297, 'BLOCK', 'CONCRETE BLOCK - 5 INCHES', 'Active', '', 1000, 10, '9E7AAB4', 'WG001', '', '2024-05-07', '1D171EF', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(337, 'INSULATION', 'KRAFT FACED ROLL BATT INSULATION', 'Active', '', 1000, 1603, '9E7AAB4', 'WG001', '', '2024-05-07', '1E37FA5', 'ROLL');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(374, 'EPS', 'STYROFOAM STORAGE BOX - SMALL', 'Active', '', 100, 75, '9E7AAB4', 'WG001', '', '2024-07-02', '1EEFCFD', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(358, 'BOX', 'STYROFOAM COOLER BOX - 61CM X 40CM X 20CM', 'Active', '', 1000, 95, '9E7AAB4', 'WG001', '', '2024-05-07', '20A7500', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(338, 'CANOPY', 'MODERN DOOR AND WINDOW CANOPIES', 'Active', '', 1000, 1470, '9E7AAB4', 'WG001', '', '2024-05-07', '22AA876', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(251, 'RS', '0.3MM STONE COATED ROOFING SHEET - RED', 'Active', '', 1000, 190, '9E7AAB4', 'WG001', '', '2024-05-07', '232A37E', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(298, 'RS', 'ANTI CORROSIVE ALUMINIUM ROOFING SHEET - GREEN', 'Active', '', 1000, 2800, '9E7AAB4', 'WG001', '', '2024-05-07', '24EC32F', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(305, 'DMP', 'DERBICOTE HIGH QUALITY BITUMINOUS EMULSION - 17 KG', 'Active', '', 1000, 650, '9E7AAB4', 'WG001', '', '2024-05-07', '2BB2CA8', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(333, 'RS', 'IBR ALUZINC ROOFING SHEET 0.4MM SMOOTH - RED', 'Active', '', 1000, 2400, '9E7AAB4', 'WG001', '', '2024-05-07', '2C002ED', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(258, 'RS', '0.4MM STONE COATED ROOFING SHEET - WHITE', 'Active', '', 1000, 190, '9E7AAB4', 'WG001', '', '2024-05-07', '2D4BEC0', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(282, 'RG', 'ANTI CORROSIVE ALUMINIUM RAIN GUTTER', 'Active', '', 1000, 140, '9E7AAB4', 'WG001', '', '2024-05-07', '2DF6A87', 'PC');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(348, 'RS', 'PPGI ROOFING SHEET - DARK GRAY', 'Active', '', 1000, 1250, '9E7AAB4', 'WG001', '', '2024-05-07', '2E02CF5', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(255, 'RS', '0.4MM STONE COATED ROOFING SHEET - BLUE', 'Active', '', 1000, 190, '9E7AAB4', 'WG001', '', '2024-05-07', '2FB42D7', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(246, 'RS', '0.3MM STONE COATED ROOFING SHEET - BLACK', 'Active', '', 1000, 190, '9E7AAB4', 'WG001', '', '2024-05-07', '2FDD17E', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(306, 'RG', 'DURABLE PVC RAIN GUTTER FOR ALL WEATHER - WHITE', 'Active', '', 1000, 180, '9E7AAB4', 'WG001', '', '2024-05-07', '3051ABE', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(280, 'INSULATION', '8MM ARMAFLEX SHEET', 'Active', '', 1000, 308, '9E7AAB4', 'WG001', '', '2024-05-07', '31389A6', 'ROLL');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(311, 'DMP', 'EMILKOTE HIGH QUALITY BITUMINOUS EMULSION - 17 KG', 'Active', '', 1000, 700, '9E7AAB4', 'WG001', '', '2024-05-07', '31BCC72', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(249, 'RS', '0.3MM STONE COATED ROOFING SHEET - BLUE', 'Active', '', 1000, 190, '9E7AAB4', 'WG001', '', '2024-05-07', '323A46D', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(296, 'RS', 'ANTI CORROSIVE ALUMINIUM ROOFING SHEET - BLUE', 'Active', '', 1000, 2800, '9E7AAB4', 'WG001', '', '2024-05-07', '32CA31C', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(365, 'RS', 'TRANSPARENT ROOFING SHEET - WINE', 'Active', '', 1000, 150, '9E7AAB4', 'WG001', '', '2024-05-07', '3852366', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(316, 'RS', 'HIGH QUALITY IBR PREMIUM ALUZINC ROOFING SHEET 0.3', 'Active', '', 1000, 1995, '9E7AAB4', 'WG001', '', '2024-05-07', '391413A', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(265, 'INSULATION', '1.2M X 8M X 100MM EARTHWOOL INSULATION ROLL - ALUMINUM FOIL', 'Active', '', 1000, 1300, '6F12BEF', 'WG001', '', '2024-05-07', '398838C', 'ROLL');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(394, 'SUGAR', 'SUGAR MILK', 'Active', '', 3234, 34, 'B63HI', 'WG004', '', '2024-12-12', '3C82833', 'CTN');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(248, 'RS', '0.3MM STONE COATED ROOFING SHEET - GREEN', 'Active', '', 1000, 190, '9E7AAB4', 'WG001', '', '2024-05-07', '3D0EDC3', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(315, 'RS', 'HIGH QUALITY IBR PREMIUM ALUZINC ROOFING SHEET 0.3', 'Active', '', 1000, 1995, '9E7AAB4', 'WG001', '', '2024-05-07', '3D6303B', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(273, 'INSULATION', '12MM POLYURETHANE ARMAFLEX SHEET', 'Active', '', 1000, 315, '9E7AAB4', 'WG001', '', '2024-05-07', '3FA53A9', 'ROLL');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(380, 'NAIL', 'ROOFING NAILS', 'Active', '', 2000, 20, '9E7AAB4', 'WG004', '', '2024-08-31', '3FB5F26', 'PKT');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(372, 'EPS', 'STYROFOAM ICE COOLER STORAGE - SMALL', 'Active', '', 100, 60, 'VT0021', 'WG001', '', '2024-07-02', '42F6402', 'PC');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(307, 'DMP', 'DANOSA IMPERDAN FP 40 GP', 'Active', '', 1000, 990, '9E7AAB4', 'WG001', '', '2024-05-07', '4339692', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(253, 'RS', '0.4MM STONE COATED ROOFING SHEET - BROWN', 'Active', '', 1000, 190, '9E7AAB4', 'WG001', '', '2024-05-07', '482BC5B', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(270, 'ROPE', '12MM POLYESTER ROPE - 48 STRANDS CORE', 'Active', '', 1000, 1596, '9E7AAB4', 'WG001', '', '2024-05-07', '4C50107', 'COIL');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(268, 'EPS', '100MM EXPANDABLE POLYSTYRENE SHEET', 'Active', '', 1000, 505, '9E7AAB4', 'WG001', '', '2024-05-07', '4E93C92', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(288, 'RS', 'ALUZINC ROOFING SHEET NON COLORED 0.3MM - GRAY', 'Active', '', 1000, 1500, '9E7AAB4', 'WG001', '', '2024-05-07', '5093C2D', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(326, 'RS', 'HIGH QUALITY INDONESIA ROOFING SLATE WHOLESALE', 'Active', '', 1000, 130, '9E7AAB4', 'WG001', '', '2024-05-07', '5231EED', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(341, 'INSULATION', 'MINERAL WOOL CAVITY BATT WALL INSULATION - 100MM', 'Active', '', 1000, 1399, '9E7AAB4', 'WG001', '', '2024-05-07', '58E607C', 'ROLL');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(357, 'BOX', 'STYROFOAM COOLER BOX - 50CM X 40CM X 20CM', 'Active', '', 1000, 90, '9E7AAB4', 'WG001', '', '2024-05-07', '590C992', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(332, 'RS', 'IBR ALUZINC ROOFING SHEET 0.4MM SMOOTH - GREEN', 'Active', '', 1000, 2400, '9E7AAB4', 'WG001', '', '2024-05-07', '5A5EB1A', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(312, 'SCREED', 'FLOOR LEVELLING SCREED 25KG LEVELFIX', 'Active', '', 1000, 269, '9E7AAB4', 'WG001', '', '2024-05-07', '5B8A1C1', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(263, 'RS', '0.5MM STONE COATED ROOFING SHEET - GREEN', 'Active', '', 1000, 190, '9E7AAB4', 'WG001', '', '2024-05-07', '5C7689E', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(285, 'INSULATION', '6MM ARMAFLEX SHEET', 'Active', '', 1000, 211, '9E7AAB4', 'WG001', '', '2024-05-07', '5C85921', 'ROLL');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(262, 'RS', '0.5MM STONE COATED ROOFING SHEET - EARTH', 'Active', '', 1000, 190, '9E7AAB4', 'WG001', '', '2024-05-07', '5DF5D50', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(379, 'ROOF', 'ANTI CORROSIVE - ALUMINIUM ROOFING SHEET - WINE', 'Active', '', 100, 3000, '9E7AAB4', 'WG001', '', '2024-07-18', '61C3CE4', 'PKT');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(378, 'EPS', '1.2M X 2M X 20MM EXPANDABLE POLYSTYRENE SHEET', 'Active', '', 100, 135, '9E7AAB4', 'WG001', '', '2024-07-16', '641EDF6', 'PC');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(291, 'RS', 'ALUZINC ROOFING SHEET NON COLORED 0.3MM - RED', 'Active', '', 1000, 1500, '9E7AAB4', 'WG001', '', '2024-05-07', '64BB99C', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(277, 'EPS', '1.2M X 2M X 25MM EXPANDABLE POLYSTYRENE SHEET', 'Active', '', 1000, 150, 'VT0021', 'WG001', '', '2024-05-07', '66094E5', 'PC');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(304, 'RG', 'DURABLE PVC RAIN GUTTER FOR ALL WEATHER - BRROWN', 'Active', '', 1000, 195, '9E7AAB4', 'WG001', '', '2024-05-07', '661EC7C', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(269, 'ROPE', '12 STRANDS NYLON ROPE FOR LANDSCAPE AND GARDENING ', 'Active', '', 1000, 720, '9E7AAB4', 'WG001', '', '2024-05-07', '66FB471', 'COIL');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(361, 'RS', 'TRANSPARENT ROOFING SHEET - GRAY', 'Active', '', 1000, 150, '9E7AAB4', 'WG001', '', '2024-05-07', '674DB90', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(321, 'RS', 'HIGH QUALITY IBR PREMIUM ALUZINC ROOFING SHEET 0.3', 'Active', '', 1000, 1950, '9E7AAB4', 'WG001', '', '2024-05-07', '68BAE76', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(389, 'RS', 'ALUZINC RIDGE CAP', 'Active', '', 23, 122, '9E7AAB4', 'WG004', '', '2024-09-27', '72ABE02', 'PC');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(309, 'DMP', 'EMULZER BITUMINOUS MEMBRANE EM300PAR', 'Active', '', 1000, 995, '9E7AAB4', 'WG001', '', '2024-05-07', '74CBA62', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(334, 'INSULATION', 'ISOVER GLASSWOOL BATT INSULATION', 'Active', '', 1000, 2450, '9E7AAB4', 'WG001', '', '2024-05-07', '7773916', 'ROLL');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(257, 'RS', '0.4MM STONE COATED ROOFING SHEET - RED', 'Active', '', 1000, 190, '9E7AAB4', 'WG001', '', '2024-05-07', '7A19BD3', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(364, 'RS', 'TRANSPARENT ROOFING SHEET - WHITE', 'Active', '', 1000, 150, '9E7AAB4', 'WG001', '', '2024-05-07', '7EB91EE', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(266, 'INSULATION', '1.2M X 8M X 100MM EARTHWOOL INSULATION ROLL - NO ALUMINIIUM FOIL', 'Active', '', 1000, 1200, '6F12BEF', 'WG001', '', '2024-05-07', '7F2B52C', 'ROLL');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(353, 'RS', 'PREMIUM GALVANIZE ROOFING SHEETS 0.3MM', 'Active', '', 1000, 895, '9E7AAB4', 'WG001', '', '2024-05-07', '7FEEA92', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(290, 'RS', 'ALUZINC ROOFING SHEET NON COLORED 0.3MM - WINE', 'Active', '', 1000, 1500, '9E7AAB4', 'WG001', '', '2024-05-07', '84C23FA', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(278, 'EPS', '18MM EXPANDABLE POLYSTYRENE SHEET', 'Active', '', 1000, 135, '9E7AAB4', 'WG001', '', '2024-05-07', '884D33C', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(250, 'RS', '0.3MM STONE COATED ROOFING SHEET - EARTH', 'Active', '', 1000, 190, '9E7AAB4', 'WG001', '', '2024-05-07', '8B17972', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(336, 'INSULATION', 'KNAUF ROCKWOOL INSULATION ROLL WITH ALUMINIUM FOIL', 'Active', '', 1000, 1200, '9E7AAB4', 'WG001', '', '2024-05-07', '8D7B21B', 'ROLL');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(323, 'RS', 'IBR-PREMIUM ALUZINC ROOFING SHEET 0.4MM ROUGH - BL', 'Active', '', 1000, 2450, '9E7AAB4', 'WG001', '', '2024-05-07', '8E285BA', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(352, 'INSULATION', 'POLYURETHANE ARMAFLEX INSULATION SHEET ALL SIZES -', 'Active', '', 1000, 195, '9E7AAB4', 'WG001', '', '2024-05-07', '8E466D7', 'ROLL');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(325, 'FLOOR', 'HYDROXYPROPYL METHYL CELLULOSE (HPMC) - 12.5 KG', 'Active', '', 1000, 800, '', 'WG001', '', '2024-05-07', '92E3904', 'BAG');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(252, 'RS', '0.4MM STONE COATED ROOFING SHEET - EARTH', 'Active', '', 1000, 190, '9E7AAB4', 'WG001', '', '2024-05-07', '9357768', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(355, 'DMP', 'PREMIUM POLYCOAT EMULSION BITUMEN', 'Active', '', 1000, 820, '9E7AAB4', 'WG001', '', '2024-05-07', '93954F4', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(295, 'FENCE', 'BINDING WIRE - LENGTH', 'Active', '', 1000, 500, '9E7AAB4', 'WG001', '', '2024-05-07', '99319FB', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(279, 'EPS', '75MM EXPANDABLE POLYSTYRENE SHEET', 'Active', '', 1000, 420, '9E7AAB4', 'WG001', '', '2024-05-07', '9966D4E', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(254, 'RS', '0.3MM STONE COATED ROOFING SHEET - WHITE', 'Active', '', 1000, 190, '9E7AAB4', 'WG001', '', '2024-05-07', '9A5E1DC', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(345, 'INSULATION', 'POLYURETHANE ARMAFLEX INSULATION SHEET ALL SIZES -', 'Active', '', 1000, 180, '9E7AAB4', 'WG001', '', '2024-05-07', '9A86C46', 'ROLL');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(390, '2930', '10M X 1.2M X 50MM EARTHWOLL INSULATION ROLL - ALUMINIUM FOIL', 'Active', '', 1000, 1000, 'A2C35DF', 'WG004', '', '2024-10-18', '9AB3DC4', 'ROLL');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(292, 'INSULATION', 'CAVITY BATT MINERAL WOOL INSULATION FOR PARTITION', 'Active', '', 1000, 2199, '9E7AAB4', 'WG001', '', '2024-05-07', '9B1EC4A', 'ROLL');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(286, 'RG', 'ANTI CORROSIVE ALUMINIUM RIDGE CAP', 'Active', '', 1000, 135, '9E7AAB4', 'WG001', '', '2024-05-07', '9B5BB32', 'PC');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(351, 'RS', 'PPGI ROOFING SHEET - WINE', 'Active', '', 1000, 1250, '9E7AAB4', 'WG001', '', '2024-05-07', '9C73FC4', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(275, 'INSULATION', '15M X 1.2M X 50MM MINERAL WOOL INSULATION ROLL - W', 'Active', '', 1000, 1200, '9E7AAB4', 'WG001', '', '2024-05-07', '9F5B464', 'ROLL');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(256, 'RS', '0.4MM STONE COATED ROOFING SHEET - GREEN', 'Active', '', 1000, 190, '9E7AAB4', 'WG001', '', '2024-05-07', 'A243C1F', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(346, 'RS', 'PPGI ROOFING SHEET - GREEN', 'Active', '', 1000, 1250, '9E7AAB4', 'WG001', '', '2024-05-07', 'A3141A4', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(260, 'RS', '0.5MM STONE COATED ROOFING SHEET - BLUE', 'Active', '', 1000, 190, '9E7AAB4', 'WG001', '', '2024-05-07', 'A43CA58', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(366, 'FLOOR', 'VARNISH - POLYURETHANE RESIN-BASED AGENT', 'Active', '', 1000, 2557, '9E7AAB4', 'WG001', '', '2024-05-07', 'A9693AE', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(287, 'RS', 'ALUZINC ROOFING SHEET NON COLORED 0.3MM - BLUE', 'Active', '', 1000, 1500, '9E7AAB4', 'WG001', '', '2024-05-07', 'AB4AB0A', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(383, 'RS', 'ANTI CORROSIVE ALUMINIUM ROOFING NAIL', 'Active', '', 70, 650, '9E7AAB4', 'WG004', '', '2024-09-03', 'AB96571', 'PC');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(343, 'RS', 'POLYCARBONATE SHEET', 'Active', '', 1000, 3256, '9E7AAB4', 'WG001', '', '2024-05-07', 'ABFD170', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(308, 'DMP', 'EMILKOTE HIGH QUALITY BITUMINOUS EMULSION - 5 KG', 'Active', '', 1000, 300, '9E7AAB4', 'WG001', '', '2024-05-07', 'AC3E586', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(299, 'RS', 'ANTI CORROSIVE ALUMINIUM ROOFING SHEET - RED', 'Active', '', 1000, 2800, '9E7AAB4', 'WG001', '', '2024-05-07', 'ACD450A', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(274, 'ROPE', '14MM POLYESTER ROPE - 48 STRANDS CORE', 'Active', '', 1000, 1128, '9E7AAB4', 'WG001', '', '2024-05-07', 'AF967A1', 'COIL');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(386, 'RS', 'PLASTIC DROPOUT', 'Active', '', 100, 100, '9E7AAB4', 'WG004', '', '2024-09-03', 'B0978A2', 'PC');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(354, 'RS', 'PREMIUM LOCAL ROOFING SLATE WHOLESALE', 'Active', '', 1000, 105, '9E7AAB4', 'WG001', '', '2024-05-07', 'B2FD38F', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(293, 'BRICK', 'BRICKS - 3 INCHES', 'Active', '', 1000, 9, '9E7AAB4', 'WG001', '', '2024-05-07', 'B3D2C0F', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(289, 'RS', 'ALUZINC ROOFING SHEET NON COLORED 0.3MM - GREEN', 'Active', '', 1000, 1500, '9E7AAB4', 'WG001', '', '2024-05-07', 'B6224BA', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(377, 'EPS', 'STYROFOAM STORAGE BOX - XX LARGE', 'Active', '', 100, 215, '9E7AAB4', 'WG001', '', '2024-07-02', 'B6F2492', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(335, 'RS', 'IBR ALUZINC ROOFING SHEET 0.4MM SMOOTH - WINE', 'Active', '', 1000, 2400, '9E7AAB4', 'WG001', '', '2024-05-07', 'B70600A', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(259, 'RS', '0.5MM STONE COATED ROOFING SHEET - BLACK', 'Active', '', 1000, 190, '9E7AAB4', 'WG001', '', '2024-05-07', 'B777C75', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(261, 'RS', '0.5MM STONE COATED ROOFING SHEET - BROWN', 'Active', '', 1000, 190, '9E7AAB4', 'WG001', '', '2024-05-07', 'B7C6202', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(294, 'BRICK', 'BRICKS - 2 INCHES', 'Active', '', 1000, 8, '9E7AAB4', 'WG001', '', '2024-05-07', 'BA27D89', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(373, 'EPS', 'STYROFOAM STORAGE BOX - MEDIUM', 'Active', '', 100, 85, '9E7AAB4', 'WG001', '', '2024-07-02', 'BD2B1A2', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(313, 'RS', 'HIGH QUALITY IBR PREMIUM ALUZINC ROOFING SHEET 0.3', 'Active', '', 1000, 1995, '9E7AAB4', 'WG001', '', '2024-05-07', 'BDFAE71', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(310, 'INSULATION', 'FIBERGLASS ROLL INSULATION', 'Active', '', 70, 2320, 'A2C35DF', 'WG001', '', '2024-05-07', 'BE949DC', 'ROLL');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(328, 'RS', 'IBR-PREMIUM ALUZINC ROOFING SHEET 0.4MM ROUGH - WI', 'Active', '', 1000, 2450, '9E7AAB4', 'WG001', '', '2024-05-07', 'C4D617A', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(324, 'FLOOR', 'HYDROXYPROPYL METHYL CELLULOSE HPMC - 25KG', 'Active', '', 1000, 1352, '9E7AAB4', 'WG001', '', '2024-05-07', 'C779916', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(342, 'DMP', 'NATURAL SOLID BITUMEN INDUSTRIAL GRADE - 20 KG', 'Active', '', 1000, 850, '9E7AAB4', 'WG001', '', '2024-05-07', 'C949008', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(391, 'SWEET', 'SAMPLE PRODUCT', 'Active', '', 100, 100, 'VT0021', 'WG004', '', '2024-11-24', 'C9E37C2', 'TIER');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(322, 'RS', 'HIGH QUALITY IBR PREMIUM ALUZINC ROOFING SHEET 0.3', 'Active', '', 1000, 1950, '9E7AAB4', 'WG001', '', '2024-05-07', 'CAD3B4D', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(318, 'RS', 'HIGH QUALITY IBR PREMIUM ALUZINC ROOFING SHEET 0.3', 'Active', '', 1000, 1950, '9E7AAB4', 'WG001', '', '2024-05-07', 'CB65FD8', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(367, 'SCREED', 'WEBBER FLOOR LEVELLING SCREED 25KG PREMIUM - 25KG', 'Active', '', 1000, 585, '9E7AAB4', 'WG001', '', '2024-05-07', 'CC1B140', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(360, 'RS', 'TRANSPARENT ROOFING SHEET - BLUE', 'Active', '', 1000, 150, '9E7AAB4', 'WG001', '', '2024-05-07', 'CC491D9', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(300, 'RS', 'ANTI CORROSIVE ALUMINIUM ROOFING SHEET - WINE', 'Active', '', 1000, 2800, '9E7AAB4', 'WG001', '', '2024-05-07', 'CCA13BD', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(283, 'RG', 'ALUMINIUM METALLIC RAIN GUTTER FOR ALL WEATHER - G', 'Active', '', 1000, 135, '9E7AAB4', 'WG001', '', '2024-05-07', 'CD08D6A', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(388, 'RS', 'ALUINC RAIN GUTTER', 'Active', '', 1222, 100, '9E7AAB4', 'WG004', '', '2024-09-27', 'CEAFBDB', 'PC');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(331, 'RS', 'IBR ALUZINC ROOFING SHEET 0.4MM SMOOTH - COFFEE', 'Active', '', 1000, 2400, '9E7AAB4', 'WG001', '', '2024-05-07', 'D1D93C2', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(381, 'RS', 'PLASTIC HOOKS', 'Active', '', 1000, 100, '9E7AAB4', 'WG004', '', '2024-09-03', 'D6953DE', 'PC');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(320, 'RS', 'HIGH QUALITY IBR PREMIUM ALUZINC ROOFING SHEET 0.3', 'Active', '', 1000, 1950, '9E7AAB4', 'WG001', '', '2024-05-07', 'D6A23DA', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(387, 'RS', 'ANTI CORROSIVE ALUMINIUM VALLEY CAP', 'Active', '', 7, 1500, '9E7AAB4', 'WG004', '', '2024-09-03', 'D7B1061', 'PC');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(302, 'BLOCK', 'CONCRETE BLOCK - 6 INCHES', 'Active', '', 1000, 10, '9E7AAB4', 'WG001', '', '2024-05-07', 'D8A4162', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(330, 'RS', 'IBR-PREMIUM ALUZINC ROOFING SHEET 0.4MM ROUGH - GR', 'Active', '', 1000, 2450, '9E7AAB4', 'WG001', '', '2024-05-07', 'D8D0487', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(264, 'RS', '0.5MM STONE COATED ROOFING SHEET - RED', 'Active', '', 1000, 190, '9E7AAB4', 'WG001', '', '2024-05-07', 'D9F23C0', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(247, 'RS', '0.3MM STONE COATED ROOFING SHEET - BROWN', 'Active', '', 1000, 190, '9E7AAB4', 'WG001', '', '2024-05-07', 'DBA40F1', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(319, 'RS', 'HIGH QUALITY IBR PREMIUM ALUZINC ROOFING SHEET 0.3', 'Active', '', 1000, 1995, '9E7AAB4', 'WG001', '', '2024-05-07', 'DCC5E81', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(281, 'RG', 'ALUMINIUM METALLIC RAIN GUTTER FOR ALL WEATHER - B', 'Active', '', 1000, 135, '9E7AAB4', 'WG001', '', '2024-05-07', 'DDC2D89', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(284, 'EPS', '1.2M X 2M X 50MM EXPANDABLE POLYSTYRENE SHEET', 'Active', '', 1000, 295, 'A2C35DF', 'WG001', '', '2024-05-07', 'DFFE05E', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(276, 'INSULATION', '15M X 1.2M X 50MM MINERAL WOOL INSULATION ROLL - W', 'Active', '', 0, 920, '9E7AAB4', 'WG001', '', '2024-05-07', 'E18B150', 'ROLL');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(267, 'RS', '0.5MM STONE COATED ROOFING SHEET - WHITE', 'Active', '', 1000, 190, '9E7AAB4', 'WG001', '', '2024-05-07', 'E77A420', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(314, 'RS', 'HIGH QUALITY IBR PREMIUM ALUZINC ROOFING SHEET 0.3', 'Active', '', 1000, 1995, '9E7AAB4', 'WG001', '', '2024-05-07', 'E7E40A7', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(329, 'RS', 'IBR ALUZINC ROOFING SHEET 0.4MM SMOOTH - BLUE', 'Active', '', 1000, 2400, '9E7AAB4', 'WG001', '', '2024-05-07', 'E8BEBDB', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(350, 'INSULATION', 'POLYURETHANE ARMAFLEX INSULATION SHEET ALL SIZES -', 'Active', '', 1000, 250, '9E7AAB4', 'WG001', '', '2024-05-07', 'EAA8CCB', 'ROLL');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(339, 'INSULATION', 'KNAUF ROCKWOOL INSULATION BATT', 'Active', '', 1000, 1685, '9E7AAB4', 'WG001', '', '2024-05-07', 'F02BD80', 'ROLL');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(272, 'EPS', '1.2M X 2M X 12.5MM EXPANDABLE POLYSTYRENE SHEET', 'Active', '', 1000, 80, '9E7AAB4', 'WG001', '', '2024-05-07', 'F248D75', 'PC');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(303, 'DMP', 'DERBICOTE HIGH QUALITY BITUMINOUS EMULSION - 5 KG', 'Active', '', 1000, 250, '9E7AAB4', 'WG001', '', '2024-05-07', 'F3FBD15', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(344, 'INSULATION', 'ODE STARFLEX GLASSWOOL INSULATION ROLL', 'Active', '', 1000, 1500, '9E7AAB4', 'WG001', '', '2024-05-07', 'F5AB37A', 'ROLL');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(385, 'RS', 'PLASTIC RAIN GUTTER', 'Active', '', 100, 100, '', 'WG004', '', '2024-09-03', 'F62FB73', 'PC');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(359, 'BOX', 'STYROFOAM STORAGE BOX FOR FISH AND TILAPIA STORAGE', 'Active', '', 1000, 180, '9E7AAB4', 'WG001', '', '2024-05-07', 'FB96524', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(375, 'EPS', 'STYROFOAM STORAGE BOX - LARGE', 'Active', '', 100, 95, '9E7AAB4', 'WG001', '', '2024-07-02', 'FC028F9', 'PCS');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(301, 'RS', 'ANTI CORROSIVE ALUMINIUM ROOFING SHEET - GRAY', 'Active', '', 1000, 2800, '9E7AAB4', 'WG001', '', '2024-05-07', 'FD96EF1', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(363, 'RS', 'TRANSPARENT ROOFING SHEET - CLEAR', 'Active', '', 1000, 150, '9E7AAB4', 'WG001', '', '2024-05-07', 'FED2099', 'BND');
INSERT INTO `inventory` (`Itm_autoincrement`, `Itm_cat`, `Itm_name`, `Itm_status`, `Itm_img`, `Itm_qty`, `Itm_price`, `Itm_sup_id`, `Itm_usr_id`, `Itm_taxable`, `itm_date`, `Itm_id`, `Itm_UOM`) VALUES
(271, 'FENCE', '1200MM X 2400MM WELDED MESH', 'Active', '', 1000, 150, '9E7AAB4', 'WG001', '', '2024-05-07', 'FEF9C87', 'PCS');

CREATE TABLE `invoice` (
  `Inv_ID_auto` int(15) NOT NULL,
  `Inv_Check` varchar(20) NOT NULL DEFAULT current_timestamp(),
  `Inv_user` varchar(30) DEFAULT NULL,
  `Inv_total_amt` decimal(10,2) DEFAULT 0.00,
  `Inv_status` enum('Purchase','Invoice','Refund','Refund_Cancellation','Partial_Refund','Proforma Invoice') DEFAULT 'Proforma Invoice',
  `Inv_Calc_Type` varchar(20) DEFAULT 'INCLUSIVE',
  `Inv_date` date DEFAULT current_timestamp(),
  `currency` enum('GHS','USD','GBP','EUR') DEFAULT 'GHS',
  `Inv_Sale_Type` varchar(15) DEFAULT 'NORMAL',
  `Inv_Number` varchar(30) NOT NULL,
  `Inv_Customer_Tin` varchar(15) DEFAULT 'C0000000000',
  `Inv_Cus_ID` varchar(20) NOT NULL,
  `Inv_discount` decimal(10,2) DEFAULT 0.00,
  `Inv_ext_Rate` decimal(10,2) DEFAULT 0.00,
  `Inv_vat` decimal(10,2) DEFAULT 0.00,
  `Inv_id` varchar(36) NOT NULL DEFAULT current_timestamp(),
  `Inv_Reference` varchar(100) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `nhil` decimal(10,2) DEFAULT 0.00,
  `getfund` decimal(10,2) DEFAULT 0.00,
  `covid` decimal(10,2) DEFAULT 0.00,
  `cst` decimal(10,2) DEFAULT 0.00,
  `tourism` decimal(10,2) DEFAULT 0.00,
  `Inv_Discount_Type` varchar(20) DEFAULT NULL,
  `ysdcid` varchar(20) DEFAULT NULL,
  `ysdcrecnum` varchar(32) DEFAULT NULL,
  `ysdcintdata` varchar(35) DEFAULT NULL,
  `ysdcregsig` varchar(25) DEFAULT NULL,
  `ysdcmrc` varchar(15) DEFAULT NULL,
  `ysdcmrctim` varchar(20) DEFAULT NULL,
  `ysdctime` varchar(20) DEFAULT NULL,
  `qr_code` text DEFAULT NULL,
  `Inv_delivery_fee` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(614, 'AS2', 'Alfred', 20650.00, 'Proforma Invoice', 'INCLUSIVE', '2024-08-13', 'GHS', 'NORMAL', 'WG24M86CSD', 'C0000000000', '9984F74', 0.00, 1.00, 2693.48, '4849E10', '', '', 423.50, 423.50, 169.40, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(616, 'AS3', 'Alfred', 2835.00, 'Proforma Invoice', 'INCLUSIVE', '2024-08-15', 'GHS', 'NORMAL', 'WG24M87CSD', 'C0000000000', 'AC22926', 0.00, 1.00, 369.78, '09E1889', '', '', 58.14, 58.14, 23.26, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(620, 'AS4', 'Alfred', 9440.00, 'Proforma Invoice', 'INCLUSIVE', '2024-08-20', 'GHS', 'NORMAL', 'WG24M89CSD', 'C0000000000', 'B22B1DD', 472.00, 1.00, 1169.74, '995D926', '', '', 183.92, 183.92, 73.57, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(625, 'AS5', 'Alfred', 1500.00, 'Proforma Invoice', 'INCLUSIVE', '2024-08-20', 'GHS', 'NORMAL', 'WG24M811CSD', 'C0000000000', '7EF6983', 0.00, 1.00, 195.65, '70708BD', '', '', 30.76, 30.76, 12.31, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '70');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(631, 'AS6', 'Alfred', 3540.00, 'Proforma Invoice', 'INCLUSIVE', '2024-08-30', 'GHS', 'NORMAL', 'WG24M812CSD', 'C0000000000', 'F9D9BB1', 0.00, 1.00, 461.74, '169029A', '', '', 72.60, 72.60, 29.04, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(632, 'AS7', 'Alfred', 29140.00, 'Proforma Invoice', 'INCLUSIVE', '2024-08-30', 'GHS', 'NORMAL', 'WG24M813CSD', 'C0000000000', '444C693', 0.00, 1.00, 3800.87, 'F9863E5', '', '', 597.62, 597.62, 239.05, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(636, 'AS10', 'Alfred', 3310.00, 'Proforma Invoice', 'INCLUSIVE', '2024-09-03', 'GHS', 'NORMAL', 'WG24M92CSD', 'C0000000000', 'C047DA1', 0.00, 1.00, 431.74, '82F1F70', '', '', 67.88, 67.88, 27.15, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(637, 'AS11', 'Alfred', 3750.00, 'Proforma Invoice', 'INCLUSIVE', '2024-09-13', 'GHS', 'NORMAL', 'WG24M93CSD', 'C0000000000', '7EF6983', 0.00, 1.00, 489.13, '728EF74', '', '', 76.91, 76.91, 30.76, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(638, 'AS12', 'Alfred', 2250.00, 'Proforma Invoice', 'INCLUSIVE', '2024-09-24', 'GHS', 'NORMAL', 'WG24M94CSD', 'C0000000000', '6FA9619', 0.00, 1.00, 293.48, '9955155', '', '', 46.14, 46.14, 18.46, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(639, 'AS13', 'Alfred', 750.00, 'Proforma Invoice', 'INCLUSIVE', '2024-09-24', 'GHS', 'NORMAL', 'WG24M95CSD', 'C0000000000', '32D652E', 0.00, 1.00, 97.83, 'ECD2B35', '', '', 15.38, 15.38, 6.15, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(640, 'AS14', 'Alfred', 59000.00, 'Proforma Invoice', 'INCLUSIVE', '2024-09-24', 'GHS', 'NORMAL', 'WG24M96CSD', 'C0000000000', '97322A1', 0.00, 1.00, 7695.65, 'AEF6A92', '', '', 1210.01, 1210.01, 484.00, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Free');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(642, 'AS15', 'Alfred', 6000.00, 'Proforma Invoice', 'INCLUSIVE', '2024-09-26', 'GHS', 'NORMAL', 'WG24M97CSD', 'C0000000000', 'F5D3A97', 0.00, 1.00, 782.61, 'B8130F5', '', '', 123.05, 123.05, 49.22, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '70');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(643, 'AS16', 'Alfred', 67890.00, 'Proforma Invoice', 'INCLUSIVE', '2024-09-27', 'GHS', 'NORMAL', 'WG24M98CSD', 'C0000000000', '333B295', 0.00, 1.00, 8855.22, 'FB8B33B', '', '', 1392.33, 1392.33, 556.93, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(646, 'AS17', 'Alfred', 39000.00, 'Proforma Invoice', 'INCLUSIVE', '2024-10-01', 'GHS', 'NORMAL', 'WG24M101CSD', 'C0000000000', '61C950E', 0.00, 1.00, 5086.96, '70456FC', '', '', 799.84, 799.84, 319.93, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(647, '864F11F', 'Alfred', 2340.00, 'Proforma Invoice', 'INCLUSIVE', '2024-10-09', 'GHS', 'NORMAL', 'OP24M102CSD', 'C0000000000', '991C8B6', 0.00, 1.00, 305.22, '99E2C96', '', '', 47.99, 47.99, 19.20, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '50');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(648, 'F0BB8BB', 'Alfred', 29500.00, 'Proforma Invoice', 'INCLUSIVE', '2024-10-10', 'GHS', 'NORMAL', 'OP24M103CSD', 'C0000000000', '97322A1', 0.00, 1.00, 3847.83, '28CA7DD', '', '', 605.00, 605.00, 242.00, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(649, '91BF98E', 'Warehouse.Ghana', 100.00, 'Invoice', 'INCLUSIVE', '2024-10-10', 'GHS', 'NORMAL', 'OP24M104CSD', 'C0000000000', '5683766', 0.00, 1.00, 13.04, 'A386A24', '', '', 2.05, 2.05, 0.82, 0.00, 0.00, 'GENERAL', 'E000010001', '10001-6072-NS1', 'VAA5-643A-LP3K-VJJG-MTNT-PWIA-BY', '7ZZV-LQOS-S6DU-EORX', '00:0C:29:0D:90:', '2024/10/10 06:54:03', '2024/10/10 06:54:03', 'https://evat-verificationqa.persolqa.com?data=Tgwfru4p/COzuGWHqIam5SPYWk/jbLSh7KWmAi5FDDiDCXmeRGsFdGlWRMClRVQUGjMkxubJJ8PBi/ndpikRiq+hq/pwxvxTg4/j/4TOcQspYVMn0M46JVs8kRRKNG1jSNh+SbdEK+5gVyc+BMo+xjWL+kBRotApJ41Gxy0Wx0dozM+h5kykkgVbPeKwHsNGarBlS65AEDIzbZwZICLbY9ua/B97Ok2YNjO3c8l/6PUlE+bwzVZk68qUww8FJIlqRmZ1DiV4kvNNAaiKJh8mc3ZRMp3MVOijI7n4Crwwjl30lPR0Dytl5XhYpsnqt6F1&v=1.1&t=i', '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(650, '91BF98E', 'Alfred', 100.00, 'Partial_Refund', 'INCLUSIVE', '2024-10-14', 'GHS', 'NORMAL', 'OP24M104CSD', 'C0000000000', '5683766', 0.00, 1.00, 13.04, 'AAF99CE', '7454755706', '', 2.05, 2.05, 0.82, 0.00, 0.00, 'GENERAL', 'E000010001', '10001-6076-NR1', 'VAA5-643A-LP3K-VJJG-MTNT-PWIA-BY', 'XP2V-OHA4-4QX4-R2NL', '00:0C:29:0D:90:', '2024/10/14 18:14:35', '2024/10/14 18:14:35', 'https://evat-verificationqa.persolqa.com?data=Tgwfru4p/COzuGWHqIam5SPYWk/jbLSh7KWmAi5FDDiDCXmeRGsFdGlWRMClRVQUGjMkxubJJ8PBi/ndpikRiq+hq/pwxvxTg4/j/4TOcQuzgfRA4jAAZY6RREUr+CrJyOpcUMCCcZmB19euqyRga1oPft3W8OCvPF3+SnjuD6GB+RnLzy4IR5BTsGuQSW5NRwYmbi7i5GXA7iSwJQ82IGDpv1Om2znLEIEoZJFSnpUNQRjqJcCHXpm1rTuCU0rsAezO8MuvZfKnFJRJ8wojTBanksARNqGy2HgtyFNJHUw=&v=1.1&t=i', '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(651, 'DE5EC91', 'Alfred', 1000000.00, 'Invoice', 'INCLUSIVE', '2024-10-14', 'GHS', 'NORMAL', 'OP24M106CSD', 'C0000000000', 'B2CA8C7', 120.00, 1.00, 130434.78, '7BBD211', '', 'Thank you. ', 20508.61, 20508.61, 8203.45, 0.00, 0.00, 'SELECTIVE', 'E000010001', '10001-6076-NS1', '4BFE-QOF4-TEKQ-MEC4-5GHZ-226M-IU', 'CRFC-5LKV-6O6A-ZFAQ', '00:0C:29:0D:90:', '2024/10/14 22:20:30', '2024/10/14 22:20:30', 'https://evat-verificationqa.persolqa.com?data=Tgwfru4p/COzuGWHqIam5bxtAXpVrQcZ+r8wQvTpkdQeit/q5xEVey989m44o9haQOnJHvBRqRJWkxaZFNzULgqWYhhjs2kvNmzyAXHn5GsmXWnacElJZ4V2l75HUNgDt8JuVn67dgfBiu5PudRI9e9t03CwhFeIPdj1n80X/p9RFsmTcCczvhK65GyAeLMnRk9i4RE0t2TIQiiF47fWyn2VHk9vcpvDtQ0ArnEZJ3oGlP1eS2+339HOKoKRpyHXNfcCzWH/+hIDkuv95pJk6jLjygggxIzLexI3o+PwXYYeDsXTEAfWr5j+/RAdKuv3&v=1.1&t=i', 'Free');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(653, '8D117E5', 'Alfred', 136800.00, 'Proforma Invoice', 'INCLUSIVE', '2024-10-18', 'GHS', 'NORMAL', 'WG24M107CSD', 'C0000000000', '0B16EA8', 0.00, 1.00, 17843.48, '6B32C7C', '', '', 2805.58, 2805.58, 1122.23, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(654, '383A24B', 'Alfred', 115000.00, 'Proforma Invoice', 'INCLUSIVE', '2024-10-18', 'GHS', 'NORMAL', 'WG24M108CSD', 'C0000000000', '0B16EA8', 0.00, 1.00, 15000.00, '09E4E53', '', '', 2358.49, 2358.49, 943.40, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(655, '85549C6', 'Alfred', 2398.00, 'Proforma Invoice', 'INCLUSIVE', '2024-10-21', 'GHS', 'NORMAL', 'WG24M109CSD', 'C0000000000', 'D487AC1', 0.00, 1.00, 312.78, '23E861B', '', '', 49.18, 49.18, 19.67, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(660, 'ACB15F2', 'Alfred', 17220.00, 'Invoice', 'INCLUSIVE', '2024-11-02', 'GHS', 'NORMAL', 'WG24M1131CSD', 'C0000000000', '9C1C0A4', 0.00, 1.00, 2246.09, 'F21BC3D', '', '', 353.16, 353.16, 141.26, 0.00, 0.00, 'GENERAL', 'E000010001', '10001-608A-NS1', 'AVJN-Q47B-ELLI-GTED-7QXM-3CHI-TE', 'R3VS-WMMO-KYCB-BDQP', '00:0C:29:0D:90:', '2024/11/03 12:21:54', '2024/11/03 12:21:54', 'https://evat-verificationqa.persolqa.com?data=Tgwfru4p/COzuGWHqIam5UFPeu9WDrVg08ZXn6HwZYwYqzjQn/ugGJjltw9/JIRKUVMk6qFgAc0qMCqhy0Npg1xguZOL3iahzGCa98SK2QZePJM4C8nQ9JUhgg/xPwsmeAsM7zSFHXShzUY6m/4YYCPs55xlyXXjG+SyGcxJ72JC/zcAx0mLLSkg/8oFOhFekANVP92KsG7HRPsMG658KaCyQLL20H0ywi5hVVs+cS59Li4GcszKHtND79BYsnj7AP2P3ZrjK3ktbJtYgLjxV9fjLD8W5eXxn9tW+U+FA+VwzjGJjbYRavarz0C8k/qu&v=1.1&t=i', '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(661, '0344DD5', 'Alfred', 4920.00, 'Partial_Refund', 'INCLUSIVE', '2024-11-03', 'GHS', 'NORMAL', 'WG24M1131CSD', 'C0000000000', '9C1C0A4', 0.00, 1.00, 641.74, 'D8E48B8', '9431330789', '', 100.90, 100.90, 40.36, 0.00, 0.00, 'GENERAL', 'E000010001', '10001-608A-NR1', 'GU5K-BPB3-37IK-PK7Q-BXZR-CRBH-GA', 'YLHY-OVIG-ZRYE-UIGT', '00:0C:29:0D:90:', '2024/11/03 12:22:12', '2024/11/03 12:22:12', 'https://evat-verificationqa.persolqa.com?data=nCmAgix63pQSdMVDRVA6GMMBJNxf03z6kNzSF4ddKDGWK1C5UNPuglkMqr+s/JbMgdaY/9bvdgYe+IREuMm2sFyG+7RxDWD4Nky3dOALl8QFM1993KTe2+xkCYExOKJ7c5Nz6zDY89jxMbhHTDHspJVqPwiTJDaFv78F3fHTJATXzjdwlxiILBJylllHKuluCz3VLwxr5lofONlg96GB5J9lamxH3RhtLpt88B2nLblOESy7t/U7HbMfYjvZ5yb+oKdXsigkzwkVT/F3MnpEXFdmNH4KfGAs/1Mr19EcQIyTgaENLq1iu2wBAmpr3OQw&v=1.1&t=i', '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(662, '6D58664', 'Alfred', 29940.00, 'Proforma Invoice', 'INCLUSIVE', '2024-11-13', 'GHS', 'NORMAL', 'WG24M11133CSD', 'C0000000000', '444C693', 0.00, 1.00, 3905.22, '0D779A1', '', '', 614.03, 614.03, 245.61, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(663, '51FCE6B', 'Alfred', 190.00, 'Proforma Invoice', 'INCLUSIVE', '2024-11-22', 'GHS', 'NORMAL', 'WG24M11224CSD', 'C0000000000', '333B295', 0.00, 1.00, 24.78, '9278431', '', '', 3.90, 3.90, 1.56, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(664, 'F707797', 'Alfred', 1500.00, 'Proforma Invoice', 'INCLUSIVE', '2024-11-22', 'GHS', 'NORMAL', 'WG24M11225CSD', 'C0000000000', '32D652E', 0.00, 1.00, 195.65, '0B3D9C3', '', '', 30.76, 30.76, 12.31, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(665, '60CCCE8', 'Alfred', 1500.00, 'Invoice', 'INCLUSIVE', '2024-11-22', 'GHS', 'NORMAL', 'WG24M11226CSD', 'C0000000000', '5683766', 0.00, 1.00, 195.65, '44EC1B5', '', '', 30.76, 30.76, 12.31, 0.00, 0.00, 'GENERAL', 'E000034007', '34007-609D-NS1', 'XYVH-WYCV-EHBO-UHXT-VHDD-BHXF-5I', 'NCKH-GAZW-LMTD-OGVB', '00:0C:29:0D:90:', '2024/11/22 16:23:38', '2024/11/22 16:23:38', 'https://verification.vat-gh.com?data=Tgwfru4p/COzuGWHqIam5fsD+LdDpv9s2/g83NtfwCAd/V6M1S0KzfW04It2QNIeIp/0XFlnnMbi9buyptvyb99IkJ3UxkPuJ3fCIPNTgt1xg+nTYsN7oypMXOG0phIW6DAZeDNBkqbO2rxQhtbkME2y1sa/BE+3+gZxsaQ+NxucfK4qQz9t1IcYTleMBjH8b5o8BMhADTb/MdrB9qTMQUB71OFXY6JJKIKY3AFFi4gbGTIIYHm+0rvc306rrPW0AeB+sJJGdkwZTzcAbdyOKStlzScTj3KeiGRjVrbp9hV8cp9wAToN1xwSbIcomNY6&v=1.1&t=i', '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(666, 'F5D14F4', 'Alfred', 8.00, 'Proforma Invoice', 'INCLUSIVE', '2024-11-21', 'GHS', 'NORMAL', 'WG24M11227CSD', 'C0000000000', '6FA9619', 0.00, 1.00, 1.04, 'ADC6720', '', '', 0.16, 0.16, 0.07, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(667, 'F13986A', 'Alfred', 2450.00, 'Proforma Invoice', 'INCLUSIVE', '2024-11-23', 'GHS', 'NORMAL', 'WG24M11238CSD', 'C0000000000', '333B295', 0.00, 1.00, 319.57, '6AB4C2C', '', '', 50.25, 50.25, 20.10, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(668, 'C469F25', 'Alfred', 800.00, 'Proforma Invoice', 'INCLUSIVE', '2024-11-23', 'GHS', 'NORMAL', 'WG24M11239CSD', 'C0000000000', '6D56E31', 0.00, 1.00, 104.35, '7B19F77', '', '', 16.41, 16.41, 6.56, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(669, '51D02A3', 'Alfred', 190.00, 'Proforma Invoice', 'INCLUSIVE', '2024-11-23', 'GHS', 'NORMAL', 'WG24M112310CSD', 'C0000000000', '61C950E', 0.00, 1.00, 24.78, 'A66B56C', '', '', 3.90, 3.90, 1.56, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(670, 'FEA5115', 'Alfred', 995.00, 'Proforma Invoice', 'INCLUSIVE', '2024-11-22', 'GHS', 'NORMAL', 'WG24M112311CSD', 'C0000000000', '6D56E31', 0.00, 1.00, 129.78, '835AF5C', '', '', 20.41, 20.41, 8.16, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(671, '2435252', 'Alfred', 190.00, 'Proforma Invoice', 'INCLUSIVE', '2024-11-22', 'GHS', 'NORMAL', 'WG24M112312CSD', 'C0000000000', '881931F', 0.00, 1.00, 24.78, '1D8120F', '', '', 3.90, 3.90, 1.56, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(672, 'AA27FAE', 'Alfred', 190.00, 'Proforma Invoice', 'INCLUSIVE', '2024-11-22', 'GHS', 'NORMAL', 'WG24M112313CSD', 'C0000000000', '79B2F77', 0.00, 1.00, 24.78, 'EA5A5F4', '', '', 3.90, 3.90, 1.56, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(673, 'C2E4F1D', 'Alfred', 190.00, 'Proforma Invoice', 'INCLUSIVE', '2024-11-22', 'GHS', 'NORMAL', 'WG24M112314CSD', 'C0000000000', '6D56E31', 0.00, 1.00, 24.78, '15A3D95', '', '', 3.90, 3.90, 1.56, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(674, '50F11D5', 'Alfred', 308.00, 'Proforma Invoice', 'INCLUSIVE', '2024-11-22', 'GHS', 'NORMAL', 'WG24M112315CSD', 'C0000000000', '79B2F77', 0.00, 1.00, 40.17, 'A0579EC', '', '', 6.32, 6.32, 2.53, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(675, 'BF04C9A', 'Alfred', 135.00, 'Proforma Invoice', 'INCLUSIVE', '2024-11-21', 'GHS', 'NORMAL', 'WG24M112316CSD', 'C0000000000', '32D652E', 0.00, 1.00, 17.61, '2B65D1E', '', '', 2.77, 2.77, 1.11, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(676, 'B432602', 'Alfred', 105.00, 'Proforma Invoice', 'INCLUSIVE', '2024-11-15', 'GHS', 'NORMAL', 'WG24M112317CSD', 'C0000000000', '5683766', 0.00, 1.00, 13.70, '739BD3B', '', '', 2.15, 2.15, 0.86, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(677, '59405BD', 'Alfred', 9.00, 'Proforma Invoice', 'INCLUSIVE', '2024-11-14', 'GHS', 'NORMAL', 'WG24M112318CSD', 'C0000000000', '5683766', 0.00, 1.00, 1.17, '067D483', '', '', 0.18, 0.18, 0.07, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(680, '321B50E0', 'Alfred', 8400.00, 'Proforma Invoice', 'INCLUSIVE', '2024-12-17', 'GHS', 'NORMAL', 'WG24M121CSD', 'P0030588901', '12B1F3B', 0.00, 1.00, 1095.65, '4AE71407', '', '', 172.27, 172.27, 68.91, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(681, '0FE3C33B', 'Alfred', 31840.00, 'Proforma Invoice', 'INCLUSIVE', '2024-12-17', 'GHS', 'NORMAL', 'WG24M122CSD', 'C0000000000', '0B16EA8', 0.00, 1.00, 4153.04, 'E62A4391', '', '', 652.99, 652.99, 261.20, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(682, 'D040770F', 'Alfred', 31840.00, 'Proforma Invoice', 'INCLUSIVE', '2024-12-17', 'GHS', 'NORMAL', 'WG24M122CSD', 'C0000000000', '0B16EA8', 0.00, 1.00, 4153.04, '3B126678', '', '', 652.99, 652.99, 261.20, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(683, 'BC0A843C', 'Alfred', 20000.00, 'Invoice', 'INCLUSIVE', '2024-12-17', 'GHS', 'NORMAL', 'WG24M124CSD', 'C0000000000', '61C950E', 0.00, 1.00, 2608.70, '53775BEA', '', '', 410.17, 410.17, 164.07, 0.00, 0.00, 'GENERAL', 'E000034007', '34007-60B6-NS1', 'SSTG-GBC4-PYIL-7THL-5CL7-MP5L-ZQ', 'ODLL-QC7Z-NDJL-SHTI', '00:0C:29:0D:90:', '2024/12/17 09:47:09', '2024/12/17 09:47:09', 'https://verification.vat-gh.com?data=deTzEWyr9Ph9CcJQ9ouYz7BuEL1EkxRCbGz9in8+j/jJDrzS54XJwTqEsNnn+pFghYZ9kidsKaP8FjCmTNtKPxCXThmv9I+LUetuAEMTMyIviedRBkA63u1GrjHPA6hrlxoFAMS4S9lqQPj32nzofywR3Nq9JfMqq9ygdgfgk8k1/x/rzYxvF1x/uTqU5jW9eZ0UdK8jFdNT3RLSVT2GcIyp5tG28l62egXM6kjVM7ELXgUGpmylmwAkY9LuJuaD7MTn3RCUGg5vZ35pL6PwhUn6jWW2ABt5YxzhZzPgqm+rxyZAbO5+ol5xnruKNwJT&v=1.1&t=i', '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(684, '59072510', 'Alfred', 380.00, 'Proforma Invoice', 'INCLUSIVE', '2024-12-17', 'GHS', 'NORMAL', 'WG24M125CSD', 'C0003314324', '0A47B9E', 0.00, 1.00, 49.57, 'A852098F', '', '', 7.79, 7.79, 3.12, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(685, '02035F7D', 'Alfred', 1500.00, 'Proforma Invoice', 'INCLUSIVE', '2024-12-17', 'GHS', 'NORMAL', 'WG24M126CSD', 'C0000000000', '5683766', 0.00, 1.00, 195.65, '6CC107C2', '', '', 30.76, 30.76, 12.31, 0.00, 0.00, 'GENERAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(688, '740FE7E4', 'Alfred', 20000.00, 'Partial_Refund', 'INCLUSIVE', '2024-12-17', 'GHS', 'NORMAL', 'WG24M124CSD', 'C0000000000', '61C950E', 0.00, 1.00, 2608.70, 'CAAD8C8C', '6804412055', '', 410.17, 410.17, 164.07, 0.00, 0.00, 'GENERAL', 'E000034007', '34007-60B6-NR1', 'SSTG-GBC4-PYIL-7THL-5CL7-MP5L-ZQ', 'YXNJ-RDM6-TLP7-2JOG', '00:0C:29:0D:90:', '2024/12/17 16:55:25', '2024/12/17 16:55:25', 'https://verification.vat-gh.com?data=deTzEWyr9Ph9CcJQ9ouYz7BuEL1EkxRCbGz9in8+j/jJDrzS54XJwTqEsNnn+pFghYZ9kidsKaP8FjCmTNtKPxCXThmv9I+LUetuAEMTMyLcVgRAv4yBKf6kbCh9DKrvms+Id4+w5Gt1teeN8Wm1xBPEVATBvciuWDyFfSBqbBepgawZk4nS+BYUCim3YuFG8Z0+m891su9vnawoUzbib6Yh3VCDzX4NClofx8zYbptm7/7groXi+OOh/yj84pIg86EjLAoJ0gVE2OMtYNlwnuTzkh964XVtFfLFmsMD/cb840IyBDjAWrszPyqZyYxY&v=1.1&t=i', '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(689, '43738B99', 'Alfred', 1500.00, 'Partial_Refund', 'INCLUSIVE', '2024-12-17', 'GHS', 'NORMAL', 'WG24M11226CSD', 'C0000000000', '5683766', 0.00, 1.00, 195.65, 'AEEAFFF8', '0988083030', '', 30.76, 30.76, 12.31, 0.00, 0.00, 'GENERAL', 'E000034007', '34007-60B6-NR2', 'XYVH-WYCV-EHBO-UHXT-VHDD-BHXF-5I', 'A73R-2MOW-ETI3-Z3BW', '00:0C:29:0D:90:', '2024/12/17 17:09:30', '2024/12/17 17:09:30', 'https://verification.vat-gh.com?data=Tgwfru4p/COzuGWHqIam5fsD+LdDpv9s2/g83NtfwCAd/V6M1S0KzfW04It2QNIeIp/0XFlnnMbi9buyptvyb99IkJ3UxkPuJ3fCIPNTgt2Lwo0wlMwTZsM9yMi9aYR/knKsJM/WZQAaSp3jxM9miGl9UEdj4wN7u3btLG9KIXQQNfL/o3LI3OTHVQjqFbuUdWUxMJYU6v1ehyshnFcMWuGhmoDS0FxVhtlxqFBcPZKxtnNTejr6v4piVQodZ/7SdnywVtStRCzLDqD7ClF3izRUYIcBSl661akiETWyLRnCmYcRWTzBq/QoVlhn9Skz&v=1.1&t=i', '');
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(690, 'C2E4F1D', 'Alfred', 190.00, 'Invoice', 'INCLUSIVE', '2024-11-22', 'GHS', 'NORMAL', 'WG24M112314CSD', 'C0000000000', '6D56E31', 0.00, 1.00, 24.78, 'A9B6BBBA', '', '', 3.90, 3.90, 1.56, 0.00, 0.00, 'GENERAL', 'E000034007', '34007-60B6-NS3', 'KPWD-WJAS-NECQ-GTKQ-MKDM-LRDY-QE', 'QIWQ-Y43X-UCIP-3C4J', '00:0C:29:0D:90:', '2024/12/17 17:11:36', '2024/12/17 17:11:36', 'https://verification.vat-gh.com?data=Tgwfru4p/COzuGWHqIam5e85C9IG+LuuwQ51G0bk+CMLk8I4ramguZSRR36I8gSwj6bo0HT1WHPpvyQY5X91GWOyeQ6M5PGWs71C3t46e92z4yeFhqUMuI/pdCJsvwmLDxgkoFdHQrckj6yCd+Hfio5g+MfYFQKY7m4VwtsGp9ebvWB1lBn+DFYP7z23t2gnMWKha+h8XN12K+nHlIMeAnnVzgEWGUwMoFQdmfFo0P4/WuPY5O4wieLKpZiFkJvmWMQs6XTJ8QIXuOw7XV/kj+8duFZlkRhWdoUDi99iO6jG07BkEWiM9n3k60rFVLsH&v=1.1&t=i', NULL);
INSERT INTO `invoice` (`Inv_ID_auto`, `Inv_Check`, `Inv_user`, `Inv_total_amt`, `Inv_status`, `Inv_Calc_Type`, `Inv_date`, `currency`, `Inv_Sale_Type`, `Inv_Number`, `Inv_Customer_Tin`, `Inv_Cus_ID`, `Inv_discount`, `Inv_ext_Rate`, `Inv_vat`, `Inv_id`, `Inv_Reference`, `remarks`, `nhil`, `getfund`, `covid`, `cst`, `tourism`, `Inv_Discount_Type`, `ysdcid`, `ysdcrecnum`, `ysdcintdata`, `ysdcregsig`, `ysdcmrc`, `ysdcmrctim`, `ysdctime`, `qr_code`, `Inv_delivery_fee`) VALUES
(691, '395A85B2', 'Alfred', 190.00, 'Partial_Refund', 'INCLUSIVE', '2024-12-17', 'GHS', 'NORMAL', 'WG24M112314CSD', 'C0000000000', '6D56E31', 0.00, 1.00, 24.78, '1F4D082C', '0801007652', '', 3.90, 3.90, 1.56, 0.00, 0.00, 'GENERAL', 'E000034007', '34007-60B6-NR3', 'KPWD-WJAS-NECQ-GTKQ-MKDM-LRDY-QE', 'IABX-7DB2-LNNW-HYUU', '00:0C:29:0D:90:', '2024/12/17 17:11:53', '2024/12/17 17:11:53', 'https://verification.vat-gh.com?data=Tgwfru4p/COzuGWHqIam5e85C9IG+LuuwQ51G0bk+CMLk8I4ramguZSRR36I8gSwj6bo0HT1WHPpvyQY5X91GWOyeQ6M5PGWs71C3t46e93ToCxkNXFzqICtUoOMZpXYzRsoM+Vl0GUVYzoVVNjJd+fdTNHjFJQMhG2HODvEo0v3qjm5XZLGcC8xEeidUovc0cWm3jufojZ/8SHXe+2nMwHxaaX8WErn+ulDDR5H9Zdq1WMIRSCRjeyzeSwZKoARf7TLXXDul88XSk2GfCMHUbb/atj/KmuibUy9QlaSgc0=&v=1.1&t=i', NULL);

CREATE TABLE `invoice_products` (
  `_ID` varchar(26) NOT NULL,
  `InvoiceNum_ID` varchar(25) NOT NULL,
  `Product_ID` varchar(36) NOT NULL,
  `Product_Price` decimal(10,2) NOT NULL,
  `Product_Discount` double(10,2) NOT NULL,
  `Product_Quantity` int(11) NOT NULL,
  `Product_Refunded_Quantity` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('052AE54', 'WG24M734CSD', '61C3CE4', 3050.00, 0.00, 20, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('06E45C5', 'OP24M103CSD', '5B8A1C1', 295.00, 0.00, 100, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('070CFAF', 'OP24M108CSD', '9AB3DC4', 1250.00, 0.00, 92, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('0751336', 'OP24M104CSD', '078F1E3', 100.00, 0.00, 1, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('07E1D46', 'WG24M112313CSD', '9A5E1DC', 190.00, 0.00, 1, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('0A15324', 'OP24M103CSD', '5B8A1C1', 269.00, 0.00, 100, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('0B85681', 'WG24M95CSD', '31BCC72', 750.00, 0.00, 1, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('1EADECF', 'WG24M811CSD', '66094E5', 150.00, 0.00, 10, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('2BB5F5C', 'WG24M92CSD', 'D6953DE', 30.00, 0.00, 4, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('2BC23D3', 'WG24M112310CSD', '232A37E', 190.00, 0.00, 1, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('2CF9919', 'WG24M98CSD', '72ABE02', 130.00, 0.00, 28, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('30E456A', 'WG24M92CSD', '1561627', 30.00, 0.00, 1, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('356971B', 'WG24M101CSD', '31BCC72', 780.00, 0.00, 50, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('3B5BC90D', 'WG24M126CSD', 'B6224BA', 1500.00, 0.00, 1, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('43DAD51', 'WG24M96CSD', '5B8A1C1', 295.00, 0.00, 200, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('4921597', 'OP24M109CSD', '7F2B52C', 1199.00, 0.00, 2, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('4EF6B28', 'WG24M112318CSD', 'B3D2C0F', 9.00, 0.00, 1, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('53A44B54', 'WG24M125CSD', '3D0EDC3', 190.00, 0.00, 1, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('580FEA6', 'OP24M102CSD', '31BCC72', 780.00, 0.00, 3, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('5D27319', 'OP24M106CSD', '1D171EF', 1000.00, 120.00, 1000, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('603C898', 'WG24M92CSD', 'D6953DE', 30.00, 0.00, 4, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('623433C', 'WG24M92CSD', '2DF6A87', 150.00, 0.00, 8, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('641D0BF', 'WG24M813CSD', 'CC491D9', 155.00, 0.00, 188, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('691D4E8', 'WG24M11133CSD', '3FB5F26', 20.00, 0.00, 27, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('6983DAF', 'WG24M97CSD', '31BCC72', 750.00, 0.00, 8, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('69EE69E', 'WG24M92CSD', '1561627', 30.00, 0.00, 1, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('6B0C549', 'WG24M92CSD', '9B5BB32', 140.00, 0.00, 8, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('6DC6593', 'WG24M815CSD', '61C3CE4', 3050.00, 0.00, 3, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('7010BA0', 'WG24M112311CSD', '74CBA62', 995.00, 0.00, 1, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('72E4BB2', 'WG24M92CSD', 'F62FB73', 380.00, 0.00, 1, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('7542316', 'WG24M89CSD', 'DFFE05E', 295.50, 0.00, 20, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('754352A', 'WG24M112316CSD', 'CD08D6A', 135.00, 0.00, 1, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('7E53BD4', 'WG24M815CSD', '11808F2', 3000.00, 0.00, 1, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('7E6BEAD', 'WG24M11239CSD', '92E3904', 800.00, 0.00, 1, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('7F60E6F', 'WG24M11224CSD', '232A37E', 190.00, 0.00, 1, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('84C907E', 'WG24M79CSD', '1797BBD', 1298.00, 320.00, 120, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('8CE516A', 'OP24M107CSD', '398838C', 1200.00, 0.00, 114, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('90954886', 'WG24M124CSD', '1561627', 20000.00, 0.00, 1, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('95346CB', 'WG24M11238CSD', '7773916', 2450.00, 0.00, 1, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('9954E78', 'WG24M815CSD', '3FB5F26', 20.00, 0.00, 22, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('9E1C032', 'WG24M11226CSD', '5093C2D', 1500.00, 0.00, 1, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('9F9612D', 'OP24M108CSD', '9AB3DC4', 1250.00, 0.00, 92, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('A102107', 'WG24M94CSD', '66094E5', 150.00, 0.00, 15, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('A727DAF', 'WG24M98CSD', 'B70600A', 2950.00, 0.00, 20, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('A9770D9', 'WG24M87CSD', '641EDF6', 135.00, 0.00, 21, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('AB2FFFC', 'WG24M92CSD', '078F1E3', 30.00, 0.00, 5, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('AE391B9', 'WG24M92CSD', 'D7B1061', 140.00, 0.00, 2, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('B19744F', 'WG24M92CSD', '9B5BB32', 140.00, 0.00, 8, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('B570EAC', 'WG24M98CSD', 'CEAFBDB', 150.00, 0.00, 35, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('B6C6861', 'WG24M92CSD', '2DF6A87', 150.00, 0.00, 8, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('B7291C8', 'WG24M11225CSD', '5093C2D', 1500.00, 0.00, 1, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('B72A674', 'WG24M1131CSD', 'F5AB37A', 1230.00, 0.00, 14, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('B8FD2CB', 'OP24M107CSD', '398838C', 1250.00, 0.00, 114, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('BC77017', 'WG24M112317CSD', 'B2FD38F', 105.00, 0.00, 1, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('BC9774C7', 'WG24M121CSD', '7F2B52C', 1200.00, 0.00, 7, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('BE172BD', 'WG24M11133CSD', '11808F2', 150.00, 0.00, 196, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('C16F08B', 'WG24M89CSD', '0399D1F', 12.00, 0.00, 1, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('D5C99C7', 'WG24M92CSD', 'B0978A2', 30.00, 0.00, 1, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('D5D30FCC', 'WG24M122CSD', '74CBA62', 995.00, 0.00, 32, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('D89328B', 'WG24M92CSD', '078F1E3', 30.00, 0.00, 5, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('D9F5E49', 'WG24M11227CSD', 'BA27D89', 8.00, 0.00, 1, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('DDA1015', 'WG24M112315CSD', '31389A6', 308.00, 0.00, 1, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('E1620CE', 'WG24M112312CSD', 'D9F23C0', 190.00, 0.00, 1, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('E241CD7F', 'WG24M112314CSD', '9A5E1DC', 190.00, 0.00, 1, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('E328C2A', 'WG24M86CSD', 'DFFE05E', 295.00, 0.00, 70, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('E529F373', 'WG24M125CSD', 'DBA40F1', 190.00, 0.00, 1, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('E94EAF5', 'WG24M719CSD', '641EDF6', 135.00, 0.00, 50, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('F068953', 'WG24M93CSD', '66094E5', 150.00, 0.00, 25, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('F1E947B', 'WG24M92CSD', 'F62FB73', 380.00, 0.00, 1, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('F7003F0', 'WG24M812CSD', 'DFFE05E', 295.00, 0.00, 12, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('FA61517', 'OP24M109CSD', '7F2B52C', 1199.00, 0.00, 2, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('FBC9D65', 'WG24M92CSD', 'D7B1061', 140.00, 0.00, 2, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('FC1A9A6', 'OP24M102CSD', '31BCC72', 780.00, 0.00, 3, 0);
INSERT INTO `invoice_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Price`, `Product_Discount`, `Product_Quantity`, `Product_Refunded_Quantity`) VALUES
('FD6DBB0', 'WG24M92CSD', 'B0978A2', 30.00, 0.00, 1, 0);

CREATE TABLE `suppliers` (
  `S_name` varchar(70) DEFAULT NULL,
  `S_tin` varchar(15) DEFAULT NULL,
  `S_address` varchar(30) DEFAULT NULL,
  `S_phone` varchar(15) DEFAULT NULL,
  `S_region` enum('local','foreign') DEFAULT 'local',
  `S_status` enum('active','inactive') DEFAULT 'active',
  `S_email` varchar(35) DEFAULT NULL,
  `S_exempted` enum('Taxable','Exempted','') DEFAULT 'Taxable',
  `S_rating` int(11) DEFAULT NULL,
  `S_id` varchar(10) NOT NULL,
  `S_Added_date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `suppliers` (`S_name`, `S_tin`, `S_address`, `S_phone`, `S_region`, `S_status`, `S_email`, `S_exempted`, `S_rating`, `S_id`, `S_Added_date`) VALUES
('LEADERPRICE GHANA LIMITED', 'C0003727382', 'NORTH INDUSTRIAL AREA', '0549034231', 'local', 'active', 'LEADERPRICE@GMAI.LCOM', 'Taxable', 4, '6F12BEF', '2024-06-21');
INSERT INTO `suppliers` (`S_name`, `S_tin`, `S_address`, `S_phone`, `S_region`, `S_status`, `S_email`, `S_exempted`, `S_rating`, `S_id`, `S_Added_date`) VALUES
('CITY PAINTS GHANA LIMITED', 'C0034186913', 'ACCRA', '0302000000', 'local', 'inactive', 'azar@gmail.com', 'Taxable', 1, '8652F2C', '2024-06-29');
INSERT INTO `suppliers` (`S_name`, `S_tin`, `S_address`, `S_phone`, `S_region`, `S_status`, `S_email`, `S_exempted`, `S_rating`, `S_id`, `S_Added_date`) VALUES
('SIBLINGS LOVE', 'GHA-83458325-2', 'ACCRA GHANA', '0238934593', 'local', 'active', 'SIBLING@GMAIL.COM', 'Taxable', 1, '9E7AAB4', '2024-04-07');
INSERT INTO `suppliers` (`S_name`, `S_tin`, `S_address`, `S_phone`, `S_region`, `S_status`, `S_email`, `S_exempted`, `S_rating`, `S_id`, `S_Added_date`) VALUES
('INSULATION SPECIALIST LIMITED', 'C0008923789', 'AVERNOR - CIRCLE', '0203485962', 'local', 'active', 'INSULATION@GMAIL.COM', 'Taxable', 4, 'A2C35DF', '2024-04-13');
INSERT INTO `suppliers` (`S_name`, `S_tin`, `S_address`, `S_phone`, `S_region`, `S_status`, `S_email`, `S_exempted`, `S_rating`, `S_id`, `S_Added_date`) VALUES
('PERMAFIX GHANA LIMITED', 'C0002434523', 'AVERNOR - CIRCLE', '0540544769', 'local', 'active', 'PERMAFIX@GMAIL.COM', 'Taxable', 3, 'B63H', '2024-03-31');
INSERT INTO `suppliers` (`S_name`, `S_tin`, `S_address`, `S_phone`, `S_region`, `S_status`, `S_email`, `S_exempted`, `S_rating`, `S_id`, `S_Added_date`) VALUES
('AZAR CHEMICALS MANUFACTURING LIMITED', 'C0001434523', 'SPINTEX', '0302544769', 'local', 'active', 'INFO@AZARCHEMICALS.COM', 'Taxable', 1, 'B63HI', '2024-03-31');
INSERT INTO `suppliers` (`S_name`, `S_tin`, `S_address`, `S_phone`, `S_region`, `S_status`, `S_email`, `S_exempted`, `S_rating`, `S_id`, `S_Added_date`) VALUES
('VIRTUS PRODUCTS GHANA LIMITED', 'C003898923', 'NORTH INDUSTRIAL AREA', '05405449832', 'local', 'active', 'VIRTUS@GMAIL.COM', 'Taxable', 4, 'VT0021', '2024-08-01');

CREATE TABLE `tokens` (
  `UserName` varchar(11) DEFAULT NULL,
  `TokenValue` varchar(255) NOT NULL,
  `ExpiryTimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `CreationTimestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `TokenType` varchar(50) DEFAULT NULL,
  `Status` enum('unused','used','expired','revoked') NOT NULL,
  `IPAddress` varchar(45) DEFAULT NULL,
  `UserLocation` varchar(70) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `UserAgent` varchar(255) DEFAULT NULL,
  `TokenID` char(36) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tokens` (`UserName`, `TokenValue`, `ExpiryTimestamp`, `CreationTimestamp`, `TokenType`, `Status`, `IPAddress`, `UserLocation`, `UserAgent`, `TokenID`) VALUES
('Alfred', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImphbWVzYWt3ZXRlckBnbWFpbC5jb20iLCJpYXQiOjE3MjIzNDEwNTgsImV4cCI6MTcyMjM2OTg1OH0.i5kyEluzcIRy7_xGTKh2MZgZ6mQSMZksph8KBqRD5qU', '2024-07-30 20:04:18', '2024-07-30 12:04:18', 'JWT', 'unused', '197.251.228.146', 'GH', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0', 'CB12ECA');
INSERT INTO `tokens` (`UserName`, `TokenValue`, `ExpiryTimestamp`, `CreationTimestamp`, `TokenType`, `Status`, `IPAddress`, `UserLocation`, `UserAgent`, `TokenID`) VALUES
('Aku0241', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6InlpcGV5c2V5QGdtYWlsLmNvbSIsImlhdCI6MTcyMjk3OTI1MywiZXhwIjoxNzIzMDA4MDUzfQ.BlugAGWh6Zfz-cy6EViSHXhxr1wEt3mywHkp_lyUJpU', '2024-08-07 05:20:53', '2024-08-06 21:20:53', 'JWT', 'unused', '162.0.209.22', 'US', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36', 'B0069AB');
INSERT INTO `tokens` (`UserName`, `TokenValue`, `ExpiryTimestamp`, `CreationTimestamp`, `TokenType`, `Status`, `IPAddress`, `UserLocation`, `UserAgent`, `TokenID`) VALUES
('Admin', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6IkFkbWluQG1haWwuY29tIiwiaWF0IjoxNzIyOTc5MjY3LCJleHAiOjE3MjMwMDgwNjd9.7QfdauHzriGgAFt7zgfe1Kj31bRCEMAxiyobLLihkV4', '2024-08-07 05:21:07', '2024-08-06 21:21:07', 'JWT', 'unused', '162.0.209.22', 'US', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36', '719D447');
INSERT INTO `tokens` (`UserName`, `TokenValue`, `ExpiryTimestamp`, `CreationTimestamp`, `TokenType`, `Status`, `IPAddress`, `UserLocation`, `UserAgent`, `TokenID`) VALUES
('Alfred', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImphbWVzYWt3ZXRlckBnbWFpbC5jb20iLCJpYXQiOjE3MjI5NzkyODgsImV4cCI6MTcyMzAwODA4OH0.6TR0s1oX3wOPJ9gO6DbDVrotG7BQ6_TeRybVrf_Ksmc', '2024-08-07 05:21:28', '2024-08-06 21:21:28', 'JWT', 'unused', '162.0.209.22', 'US', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36', '6BC5164');
INSERT INTO `tokens` (`UserName`, `TokenValue`, `ExpiryTimestamp`, `CreationTimestamp`, `TokenType`, `Status`, `IPAddress`, `UserLocation`, `UserAgent`, `TokenID`) VALUES
('Warehouse.G', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6IndhcmVob3VzZWdoYW5hNUBnbWFpbC5jb20iLCJpYXQiOjE3MjMxOTM1ODAsImV4cCI6MTcyMzIyMjM4MH0.1tRokMeIEw9_E1e6Zqp_yBSAjxq8otPoKQUYR_HpMq8', '2024-08-09 16:53:00', '2024-08-09 08:53:00', 'JWT', 'unused', '162.0.209.22', 'US', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 'DA95E1B');
INSERT INTO `tokens` (`UserName`, `TokenValue`, `ExpiryTimestamp`, `CreationTimestamp`, `TokenType`, `Status`, `IPAddress`, `UserLocation`, `UserAgent`, `TokenID`) VALUES
('unclejamie', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImphbWVzYWt3ZXRlcjIxQGdtYWlsLmNvbSIsImlhdCI6MTcyMzE5MzkwMCwiZXhwIjoxNzIzMjIyNzAwfQ.NLPpO1pBZTbKZB1vHc0Z5MINane97rGlQPp6BWS7ATE', '2024-08-09 16:58:20', '2024-08-09 08:58:20', 'JWT', 'unused', '162.0.209.22', 'US', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 'D2F1F6B');
INSERT INTO `tokens` (`UserName`, `TokenValue`, `ExpiryTimestamp`, `CreationTimestamp`, `TokenType`, `Status`, `IPAddress`, `UserLocation`, `UserAgent`, `TokenID`) VALUES
('Warehouse.G', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6IndhcmVob3VzZWdoYW5hNUBnbWFpbC5jb20iLCJpYXQiOjE3MjMyMDY3MjEsImV4cCI6MTcyMzIzNTUyMX0.1fhA5x6bIJqYmFE3BA5rvkP68LqJCbYPIimYIj1Vfjw', '2024-08-09 20:32:01', '2024-08-09 12:32:01', 'JWT', 'unused', '162.0.209.22', 'US', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', '6D1995D');
INSERT INTO `tokens` (`UserName`, `TokenValue`, `ExpiryTimestamp`, `CreationTimestamp`, `TokenType`, `Status`, `IPAddress`, `UserLocation`, `UserAgent`, `TokenID`) VALUES
('Warehouse.G', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6IndhcmVob3VzZWdoYW5hNUBnbWFpbC5jb20iLCJpYXQiOjE3MjMyMDcyNTgsImV4cCI6MTcyMzIzNjA1OH0.sOA1NeVDlBnCEMSOpImCBGIyc3lz1RfK5yXziXjrlYM', '2024-08-09 20:40:58', '2024-08-09 12:40:58', 'JWT', 'unused', '162.0.209.22', 'US', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 'B8E29F0');
INSERT INTO `tokens` (`UserName`, `TokenValue`, `ExpiryTimestamp`, `CreationTimestamp`, `TokenType`, `Status`, `IPAddress`, `UserLocation`, `UserAgent`, `TokenID`) VALUES
(NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE3MjMzNjIxODcsImV4cCI6MTcyMzM5MDk4N30.rKHRM-wzaWksGylmeseeovupWmqkeNwREzyv7n5lWig', '2024-08-11 15:43:07', '2024-08-11 07:43:07', 'JWT', 'unused', '162.0.209.22', 'US', 'PostmanRuntime/7.41.0', 'D679880');
INSERT INTO `tokens` (`UserName`, `TokenValue`, `ExpiryTimestamp`, `CreationTimestamp`, `TokenType`, `Status`, `IPAddress`, `UserLocation`, `UserAgent`, `TokenID`) VALUES
(NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE3MjMzNjIyMTUsImV4cCI6MTcyMzM5MTAxNX0.KDNxf-iMgMU-UrICTLDRt-tP2tDLGpwVVPcoU0v6oxs', '2024-08-11 15:43:35', '2024-08-11 07:43:35', 'JWT', 'unused', '162.0.209.22', 'US', 'PostmanRuntime/7.41.0', '124A6E6');
INSERT INTO `tokens` (`UserName`, `TokenValue`, `ExpiryTimestamp`, `CreationTimestamp`, `TokenType`, `Status`, `IPAddress`, `UserLocation`, `UserAgent`, `TokenID`) VALUES
(NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE3MjMzNjIyMjMsImV4cCI6MTcyMzM5MTAyM30.xT9VK_VEog3xAkEkEF66z5RFnfokA6dgXx95-nkzlXg', '2024-08-11 15:43:43', '2024-08-11 07:43:43', 'JWT', 'unused', '162.0.209.22', 'US', 'PostmanRuntime/7.41.0', 'D19C9AA');
INSERT INTO `tokens` (`UserName`, `TokenValue`, `ExpiryTimestamp`, `CreationTimestamp`, `TokenType`, `Status`, `IPAddress`, `UserLocation`, `UserAgent`, `TokenID`) VALUES
('unclejamie', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImphbWVzYWt3ZXRlcjIxQGdtYWlsLmNvbSIsImlhdCI6MTcyODk3Mjg2MCwiZXhwIjoxNzI5MDAxNjYwfQ.0DVFT0sXOf5BkF0PiUlV5dlD7Zm1EQ-Y6u6yKOaAKB8', '2024-10-15 14:14:20', '2024-10-15 06:14:20', 'JWT', 'unused', '162.0.209.22', 'US', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Mobile Safari/537.36', '6BE4971');
INSERT INTO `tokens` (`UserName`, `TokenValue`, `ExpiryTimestamp`, `CreationTimestamp`, `TokenType`, `Status`, `IPAddress`, `UserLocation`, `UserAgent`, `TokenID`) VALUES
('unclejamie', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImphbWVzYWt3ZXRlcjIxQGdtYWlsLmNvbSIsImlhdCI6MTcyOTAwNjEwOCwiZXhwIjoxNzI5MDM0OTA4fQ.danv7J9WNW7OEvCPdZUwOTiv4lNw3FkGhVvCA66AYC4', '2024-10-15 23:28:28', '2024-10-15 15:28:28', 'JWT', 'unused', '162.0.209.22', 'US', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', '9A2D929');

CREATE TABLE `usermanagement` (
  `Usr_FName` varchar(100) DEFAULT NULL,
  `Usr_LName` varchar(100) DEFAULT NULL,
  `Usr_name` varchar(25) DEFAULT NULL,
  `Usr_type` enum('superAdmin','admin','default','intern','guest','CSM','temporal') DEFAULT NULL,
  `Usr_status` enum('active','inactive') DEFAULT NULL,
  `Usr_phone` varchar(15) DEFAULT NULL,
  `Usr_email` varchar(50) DEFAULT NULL,
  `Usr_address` varchar(20) DEFAULT NULL,
  `Usr_dept` enum('accounts','procurement','sales','marketing','hr','legal','logistic','IT','pr') DEFAULT NULL,
  `Usr_reg_date` varchar(20) DEFAULT NULL,
  `passwd` text DEFAULT NULL,
  `activated` enum('yes','no') NOT NULL,
  `Usr_StaffID` varchar(15) DEFAULT NULL,
  `Usr_id` char(36) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `usermanagement` (`Usr_FName`, `Usr_LName`, `Usr_name`, `Usr_type`, `Usr_status`, `Usr_phone`, `Usr_email`, `Usr_address`, `Usr_dept`, `Usr_reg_date`, `passwd`, `activated`, `Usr_StaffID`, `Usr_id`) VALUES
('Warehouse', 'Ghana', 'Warehouse.Ghana', 'guest', 'active', '0245152082', 'warehouseghana5@gmail.com', 'ACCRA', 'accounts', '2024-08-09 08:32:01.', '$2a$12$SPEPoo1O4TEzVDC6Aze4p.BTAhQf05Xg/59s0FubVkE1lxVw8ve.m', 'yes', NULL, 'WG001');
INSERT INTO `usermanagement` (`Usr_FName`, `Usr_LName`, `Usr_name`, `Usr_type`, `Usr_status`, `Usr_phone`, `Usr_email`, `Usr_address`, `Usr_dept`, `Usr_reg_date`, `passwd`, `activated`, `Usr_StaffID`, `Usr_id`) VALUES
('Uncle', 'Jamie', 'unclejamie', 'superAdmin', 'active', '0540544700', 'jamesakweter21@gmail.com', '', 'IT', '2024-08-09 04:58:20.', '$2a$12$YBkO9wqEh8QivhRXEt/C2.4S/xE1mudm2yex/Of3pao5ccsWk/1wK', 'yes', NULL, 'WG003');
INSERT INTO `usermanagement` (`Usr_FName`, `Usr_LName`, `Usr_name`, `Usr_type`, `Usr_status`, `Usr_phone`, `Usr_email`, `Usr_address`, `Usr_dept`, `Usr_reg_date`, `passwd`, `activated`, `Usr_StaffID`, `Usr_id`) VALUES
('Alfred', 'Quansah', 'Alfred', 'superAdmin', 'active', '0540544760', 'jamesakweter@gmail.com', 'ACCRA', 'IT', '2024-07-30 12:04:18.', '$2a$12$ofIhDqKjhjY.s4LQ/alRAeooeyCB2VieK2xP1cQzBtdGpYxMLu/.G', 'yes', NULL, 'WG004');

CREATE TABLE `waybill` (
  `id` int(11) NOT NULL,
  `invoiceNumber` varchar(255) DEFAULT NULL,
  `issuerName` varchar(255) DEFAULT NULL,
  `customerID` varchar(255) DEFAULT NULL,
  `_mod` enum('DELIVERY','PICK UP') DEFAULT 'DELIVERY',
  `despatchDate` date DEFAULT curdate(),
  `receipientName` varchar(255) DEFAULT NULL,
  `receipientAddress` varchar(255) DEFAULT NULL,
  `receipientPhone` varchar(15) DEFAULT NULL,
  `deliveryName` varchar(255) DEFAULT NULL,
  `deliveryPhone` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `waybill` (`id`, `invoiceNumber`, `issuerName`, `customerID`, `_mod`, `despatchDate`, `receipientName`, `receipientAddress`, `receipientPhone`, `deliveryName`, `deliveryPhone`) VALUES
(35, 'WG24M12121CSD', 'Alfred', '6D56E31', 'DELIVERY', '2024-12-17', 'DAVID ADJAYE', '', '0261633626', 'AGYENIM BOATENG', '0594591572');

CREATE TABLE `waybill_products` (
  `_ID` int(11) NOT NULL,
  `InvoiceNum_ID` varchar(25) NOT NULL,
  `Product_ID` varchar(36) NOT NULL,
  `Product_Ordered` decimal(10,2) NOT NULL,
  `Product_Delivered` double(10,2) NOT NULL,
  `Product_Outstanding` int(11) NOT NULL,
  `CheckID` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `waybill_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Ordered`, `Product_Delivered`, `Product_Outstanding`, `CheckID`) VALUES
(147, 'WG24M12121CSD', '31389A6', 1.00, 2.00, 0, '29FCDC5F');
INSERT INTO `waybill_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Ordered`, `Product_Delivered`, `Product_Outstanding`, `CheckID`) VALUES
(148, 'WG24M12121CSD', '9A5E1DC', 1.00, 2.00, 0, '9C7F95E2');
INSERT INTO `waybill_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Ordered`, `Product_Delivered`, `Product_Outstanding`, `CheckID`) VALUES
(149, 'WG24M12121CSD', '323A46D', 1.00, 2.00, 0, '751D3F38');
INSERT INTO `waybill_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Ordered`, `Product_Delivered`, `Product_Outstanding`, `CheckID`) VALUES
(150, 'WG24M12121CSD', '11808F2', 1.00, 2.00, 0, 'E0E66DF0');
INSERT INTO `waybill_products` (`_ID`, `InvoiceNum_ID`, `Product_ID`, `Product_Ordered`, `Product_Delivered`, `Product_Outstanding`, `CheckID`) VALUES
(151, 'WG24M12121CSD', 'CC1B140', 1.00, 2.00, 0, '900779D6');


ALTER TABLE `all_action_logs`
  ADD PRIMARY KEY (`Act_Log_ID`),
  ADD UNIQUE KEY `Act_Log_ID` (`Act_Log_ID`);

ALTER TABLE `all_error_logs`
  ADD PRIMARY KEY (`Act_Log_ID`),
  ADD UNIQUE KEY `Act_Log_ID` (`Act_Log_ID`);

ALTER TABLE `all_message_logs`
  ADD PRIMARY KEY (`Act_Log_ID`),
  ADD UNIQUE KEY `Act_Log_ID` (`Act_Log_ID`);

ALTER TABLE `all_server_logs`
  ADD PRIMARY KEY (`Act_Log_ID`),
  ADD UNIQUE KEY `Act_Log_ID` (`Act_Log_ID`);

ALTER TABLE `all_sucesss_logs`
  ADD PRIMARY KEY (`Act_Log_ID`),
  ADD UNIQUE KEY `Act_Log_ID` (`Act_Log_ID`);

ALTER TABLE `company`
  ADD PRIMARY KEY (`Com_id`),
  ADD UNIQUE KEY `Com_id` (`Com_id`);

ALTER TABLE `customers`
  ADD PRIMARY KEY (`C_id`),
  ADD UNIQUE KEY `C_id` (`C_id`),
  ADD UNIQUE KEY `C_phone` (`C_phone`);

ALTER TABLE `inventory`
  ADD PRIMARY KEY (`Itm_id`),
  ADD UNIQUE KEY `Itm_id` (`Itm_id`),
  ADD UNIQUE KEY `Itm_autoincrement` (`Itm_autoincrement`),
  ADD KEY `Itm_id_2` (`Itm_id`),
  ADD KEY `Itm_autoincrement_2` (`Itm_autoincrement`);

ALTER TABLE `invoice`
  ADD PRIMARY KEY (`Inv_ID_auto`);

ALTER TABLE `invoice_products`
  ADD PRIMARY KEY (`_ID`);

ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`S_id`),
  ADD UNIQUE KEY `S_id` (`S_id`),
  ADD UNIQUE KEY `S_phone` (`S_phone`);

ALTER TABLE `usermanagement`
  ADD PRIMARY KEY (`Usr_id`),
  ADD UNIQUE KEY `Usr_id` (`Usr_id`),
  ADD UNIQUE KEY `Usr_phone` (`Usr_phone`),
  ADD UNIQUE KEY `Usr_email` (`Usr_email`),
  ADD KEY `Usr_id_2` (`Usr_id`);

ALTER TABLE `waybill`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `invoiceNumber` (`invoiceNumber`);

ALTER TABLE `waybill_products`
  ADD PRIMARY KEY (`_ID`);


ALTER TABLE `all_action_logs`
  MODIFY `Act_Log_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=269;

ALTER TABLE `all_error_logs`
  MODIFY `Act_Log_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=297;

ALTER TABLE `all_message_logs`
  MODIFY `Act_Log_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

ALTER TABLE `all_server_logs`
  MODIFY `Act_Log_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1001;

ALTER TABLE `all_sucesss_logs`
  MODIFY `Act_Log_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=182;

ALTER TABLE `inventory`
  MODIFY `Itm_autoincrement` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=395;

ALTER TABLE `invoice`
  MODIFY `Inv_ID_auto` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=692;

ALTER TABLE `waybill`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

ALTER TABLE `waybill_products`
  MODIFY `_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=152;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
